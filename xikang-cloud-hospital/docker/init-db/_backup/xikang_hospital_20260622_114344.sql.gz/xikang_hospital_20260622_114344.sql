--
-- PostgreSQL database dump
--

\restrict TqxD8WKVgkRGLkUYP18mE8EDbUMKASNfl1535SrZQJhSDcAD00jgcsyY1GbFNFC

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_patient_managed DROP CONSTRAINT IF EXISTS fk_upm_user;
ALTER TABLE IF EXISTS ONLY public.user_patient_managed DROP CONSTRAINT IF EXISTS fk_upm_patient;
ALTER TABLE IF EXISTS ONLY public.schedule_plan DROP CONSTRAINT IF EXISTS fk_sp_department;
ALTER TABLE IF EXISTS ONLY public.schedule_adjust_request DROP CONSTRAINT IF EXISTS fk_sar_schedule;
ALTER TABLE IF EXISTS ONLY public.schedule_adjust_log DROP CONSTRAINT IF EXISTS fk_sal_schedule;
ALTER TABLE IF EXISTS ONLY public.register DROP CONSTRAINT IF EXISTS fk_register_settle_category;
ALTER TABLE IF EXISTS ONLY public.register DROP CONSTRAINT IF EXISTS fk_register_regist_level;
ALTER TABLE IF EXISTS ONLY public.register DROP CONSTRAINT IF EXISTS fk_register_employee;
ALTER TABLE IF EXISTS ONLY public.register DROP CONSTRAINT IF EXISTS fk_register_department;
ALTER TABLE IF EXISTS ONLY public.prescription DROP CONSTRAINT IF EXISTS fk_prescription_register;
ALTER TABLE IF EXISTS ONLY public.prescription DROP CONSTRAINT IF EXISTS fk_prescription_drug;
ALTER TABLE IF EXISTS ONLY public.patient_balance_transaction DROP CONSTRAINT IF EXISTS fk_patient_balance_transaction_patient;
ALTER TABLE IF EXISTS ONLY public.medical_record_disease DROP CONSTRAINT IF EXISTS fk_mrd_medical_record;
ALTER TABLE IF EXISTS ONLY public.medical_record_disease DROP CONSTRAINT IF EXISTS fk_mrd_disease;
ALTER TABLE IF EXISTS ONLY public.medical_technology DROP CONSTRAINT IF EXISTS fk_medtech_department;
ALTER TABLE IF EXISTS ONLY public.medical_record DROP CONSTRAINT IF EXISTS fk_medical_record_register;
ALTER TABLE IF EXISTS ONLY public.leave_request DROP CONSTRAINT IF EXISTS fk_lr_physician;
ALTER TABLE IF EXISTS ONLY public.inspection_request DROP CONSTRAINT IF EXISTS fk_inspection_request_register;
ALTER TABLE IF EXISTS ONLY public.inspection_request DROP CONSTRAINT IF EXISTS fk_inspection_request_medtech;
ALTER TABLE IF EXISTS ONLY public.inspection_request DROP CONSTRAINT IF EXISTS fk_inspection_request_input_employee;
ALTER TABLE IF EXISTS ONLY public.inspection_request DROP CONSTRAINT IF EXISTS fk_inspection_request_employee;
ALTER TABLE IF EXISTS ONLY public.employee DROP CONSTRAINT IF EXISTS fk_employee_regist_level;
ALTER TABLE IF EXISTS ONLY public.employee DROP CONSTRAINT IF EXISTS fk_employee_department;
ALTER TABLE IF EXISTS ONLY public.doctor_schedule DROP CONSTRAINT IF EXISTS fk_ds_regist_level;
ALTER TABLE IF EXISTS ONLY public.doctor_schedule DROP CONSTRAINT IF EXISTS fk_ds_plan;
ALTER TABLE IF EXISTS ONLY public.doctor_schedule DROP CONSTRAINT IF EXISTS fk_ds_physician;
ALTER TABLE IF EXISTS ONLY public.doctor_schedule DROP CONSTRAINT IF EXISTS fk_ds_department;
ALTER TABLE IF EXISTS ONLY public.disposal_request DROP CONSTRAINT IF EXISTS fk_disposal_request_register;
ALTER TABLE IF EXISTS ONLY public.disposal_request DROP CONSTRAINT IF EXISTS fk_disposal_request_medtech;
ALTER TABLE IF EXISTS ONLY public.disposal_request DROP CONSTRAINT IF EXISTS fk_disposal_request_input_employee;
ALTER TABLE IF EXISTS ONLY public.disposal_request DROP CONSTRAINT IF EXISTS fk_disposal_request_employee;
ALTER TABLE IF EXISTS ONLY public.check_request DROP CONSTRAINT IF EXISTS fk_check_request_register;
ALTER TABLE IF EXISTS ONLY public.check_request DROP CONSTRAINT IF EXISTS fk_check_request_medtech;
ALTER TABLE IF EXISTS ONLY public.check_request DROP CONSTRAINT IF EXISTS fk_check_request_input_employee;
ALTER TABLE IF EXISTS ONLY public.check_request DROP CONSTRAINT IF EXISTS fk_check_request_employee;
ALTER TABLE IF EXISTS ONLY public.ai_triage_record DROP CONSTRAINT IF EXISTS fk_ai_triage_register;
ALTER TABLE IF EXISTS ONLY public.ai_triage_record DROP CONSTRAINT IF EXISTS fk_ai_triage_doctor;
ALTER TABLE IF EXISTS ONLY public.ai_triage_record DROP CONSTRAINT IF EXISTS fk_ai_triage_dept;
ALTER TABLE IF EXISTS ONLY public.ai_prescription_review DROP CONSTRAINT IF EXISTS fk_ai_review_register;
ALTER TABLE IF EXISTS ONLY public.ai_prescription_review DROP CONSTRAINT IF EXISTS fk_ai_review_prescription;
ALTER TABLE IF EXISTS ONLY public.ai_medical_record_log DROP CONSTRAINT IF EXISTS fk_ai_mrlog_register;
ALTER TABLE IF EXISTS ONLY public.ai_medical_record_log DROP CONSTRAINT IF EXISTS fk_ai_mrlog_medical_record;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_plan DROP CONSTRAINT IF EXISTS fk_ai_followup_register;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_record DROP CONSTRAINT IF EXISTS fk_ai_followup_record_register;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_record DROP CONSTRAINT IF EXISTS fk_ai_followup_record_plan;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_plan DROP CONSTRAINT IF EXISTS fk_ai_followup_prescription;
ALTER TABLE IF EXISTS ONLY public.ai_exam_suggestion DROP CONSTRAINT IF EXISTS fk_ai_exam_sug_register;
ALTER TABLE IF EXISTS ONLY public.ai_exam_suggestion DROP CONSTRAINT IF EXISTS fk_ai_exam_sug_medtech;
ALTER TABLE IF EXISTS ONLY public.ai_exam_analysis DROP CONSTRAINT IF EXISTS fk_ai_exam_analysis_register;
ALTER TABLE IF EXISTS ONLY public.ai_exam_analysis DROP CONSTRAINT IF EXISTS fk_ai_exam_analysis_inspection;
ALTER TABLE IF EXISTS ONLY public.ai_exam_analysis DROP CONSTRAINT IF EXISTS fk_ai_exam_analysis_check;
ALTER TABLE IF EXISTS ONLY public.ai_diagnosis_suggestion DROP CONSTRAINT IF EXISTS fk_ai_diagnosis_register;
ALTER TABLE IF EXISTS ONLY public.ai_diagnosis_suggestion DROP CONSTRAINT IF EXISTS fk_ai_diagnosis_disease;
ALTER TABLE IF EXISTS ONLY public.ai_consultation_record DROP CONSTRAINT IF EXISTS fk_ai_consult_register;
DROP INDEX IF EXISTS public.uk_patient_balance_transaction_business_unique;
DROP INDEX IF EXISTS public.idx_users_username;
DROP INDEX IF EXISTS public.idx_users_user_type;
DROP INDEX IF EXISTS public.idx_users_status;
DROP INDEX IF EXISTS public.idx_upm_user;
DROP INDEX IF EXISTS public.idx_upm_patient;
DROP INDEX IF EXISTS public.idx_triage_desk_status;
DROP INDEX IF EXISTS public.idx_triage_desk_patient_id;
DROP INDEX IF EXISTS public.idx_sp_status;
DROP INDEX IF EXISTS public.idx_sp_dept_month;
DROP INDEX IF EXISTS public.idx_sar_triggered_by;
DROP INDEX IF EXISTS public.idx_sar_status;
DROP INDEX IF EXISTS public.idx_sar_schedule;
DROP INDEX IF EXISTS public.idx_sal_schedule;
DROP INDEX IF EXISTS public.idx_sal_adjust_by;
DROP INDEX IF EXISTS public.idx_register_visit_state;
DROP INDEX IF EXISTS public.idx_register_visit_date;
DROP INDEX IF EXISTS public.idx_register_scheduling_id;
DROP INDEX IF EXISTS public.idx_register_real_name;
DROP INDEX IF EXISTS public.idx_register_patient_id;
DROP INDEX IF EXISTS public.idx_register_employee_id;
DROP INDEX IF EXISTS public.idx_register_deptment_id;
DROP INDEX IF EXISTS public.idx_register_case_number;
DROP INDEX IF EXISTS public.idx_prescription_state;
DROP INDEX IF EXISTS public.idx_prescription_register_id;
DROP INDEX IF EXISTS public.idx_prescription_drug_id;
DROP INDEX IF EXISTS public.idx_patient_id_card;
DROP INDEX IF EXISTS public.idx_patient_balance_transaction_patient_time;
DROP INDEX IF EXISTS public.idx_patient_balance_transaction_business;
DROP INDEX IF EXISTS public.idx_patient_account_balance;
DROP INDEX IF EXISTS public.idx_medtech_type_new;
DROP INDEX IF EXISTS public.idx_medtech_type;
DROP INDEX IF EXISTS public.idx_medtech_status;
DROP INDEX IF EXISTS public.idx_medtech_name;
DROP INDEX IF EXISTS public.idx_medtech_deptment_id;
DROP INDEX IF EXISTS public.idx_medtech_dept_new;
DROP INDEX IF EXISTS public.idx_lr_status;
DROP INDEX IF EXISTS public.idx_lr_physician;
DROP INDEX IF EXISTS public.idx_lr_date;
DROP INDEX IF EXISTS public.idx_inspection_request_state;
DROP INDEX IF EXISTS public.idx_inspection_request_register_id;
DROP INDEX IF EXISTS public.idx_expense_status;
DROP INDEX IF EXISTS public.idx_expense_register_id;
DROP INDEX IF EXISTS public.idx_expense_record_status;
DROP INDEX IF EXISTS public.idx_expense_record_register_id;
DROP INDEX IF EXISTS public.idx_expense_record_patient_id;
DROP INDEX IF EXISTS public.idx_employee_regist_level_id;
DROP INDEX IF EXISTS public.idx_employee_deptment_id;
DROP INDEX IF EXISTS public.idx_ds_unique;
DROP INDEX IF EXISTS public.idx_ds_plan;
DROP INDEX IF EXISTS public.idx_ds_physician;
DROP INDEX IF EXISTS public.idx_ds_department;
DROP INDEX IF EXISTS public.idx_ds_date;
DROP INDEX IF EXISTS public.idx_drug_type;
DROP INDEX IF EXISTS public.idx_drug_name;
DROP INDEX IF EXISTS public.idx_drug_mnemonic;
DROP INDEX IF EXISTS public.idx_drug_info_status;
DROP INDEX IF EXISTS public.idx_drug_info_name;
DROP INDEX IF EXISTS public.idx_drug_info_low_stock;
DROP INDEX IF EXISTS public.idx_disposal_request_state;
DROP INDEX IF EXISTS public.idx_disposal_request_register_id;
DROP INDEX IF EXISTS public.idx_disease_name;
DROP INDEX IF EXISTS public.idx_disease_category;
DROP INDEX IF EXISTS public.idx_check_request_state;
DROP INDEX IF EXISTS public.idx_check_request_register_id;
DROP INDEX IF EXISTS public.idx_check_request_medtech_id;
DROP INDEX IF EXISTS public.idx_ai_triage_time;
DROP INDEX IF EXISTS public.idx_ai_triage_risk_level;
DROP INDEX IF EXISTS public.idx_ai_triage_register_id;
DROP INDEX IF EXISTS public.idx_ai_review_result;
DROP INDEX IF EXISTS public.idx_ai_review_register_id;
DROP INDEX IF EXISTS public.idx_ai_review_prescription_id;
DROP INDEX IF EXISTS public.idx_ai_mrlog_register_id;
DROP INDEX IF EXISTS public.idx_ai_fur_register_id;
DROP INDEX IF EXISTS public.idx_ai_fur_plan_id;
DROP INDEX IF EXISTS public.idx_ai_followup_status;
DROP INDEX IF EXISTS public.idx_ai_followup_register_id;
DROP INDEX IF EXISTS public.idx_ai_followup_planned_date;
DROP INDEX IF EXISTS public.idx_ai_exam_sug_register_id;
DROP INDEX IF EXISTS public.idx_ai_exam_analysis_risk;
DROP INDEX IF EXISTS public.idx_ai_exam_analysis_register_id;
DROP INDEX IF EXISTS public.idx_ai_exam_analysis_inspection_id;
DROP INDEX IF EXISTS public.idx_ai_exam_analysis_check_id;
DROP INDEX IF EXISTS public.idx_ai_diagnosis_register_id;
DROP INDEX IF EXISTS public.idx_ai_diagnosis_disease_id;
DROP INDEX IF EXISTS public.idx_ai_consult_state;
DROP INDEX IF EXISTS public.idx_ai_consult_session_uuid;
DROP INDEX IF EXISTS public.idx_ai_consult_register_id;
DROP INDEX IF EXISTS public.idx_ai_consult_patient_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_patient_managed DROP CONSTRAINT IF EXISTS user_patient_managed_pkey;
ALTER TABLE IF EXISTS ONLY public.settle_category DROP CONSTRAINT IF EXISTS uk_settle_category_code;
ALTER TABLE IF EXISTS ONLY public.regist_level DROP CONSTRAINT IF EXISTS uk_regist_level_code;
ALTER TABLE IF EXISTS ONLY public.patient_balance_transaction DROP CONSTRAINT IF EXISTS uk_patient_balance_transaction_no;
ALTER TABLE IF EXISTS ONLY public.medical_technology DROP CONSTRAINT IF EXISTS uk_medtech_code;
ALTER TABLE IF EXISTS ONLY public.medical_record DROP CONSTRAINT IF EXISTS uk_medical_record_register;
ALTER TABLE IF EXISTS ONLY public.drug_info DROP CONSTRAINT IF EXISTS uk_drug_code;
ALTER TABLE IF EXISTS ONLY public.disease DROP CONSTRAINT IF EXISTS uk_disease_icd;
ALTER TABLE IF EXISTS ONLY public.department DROP CONSTRAINT IF EXISTS uk_department_dept_code;
ALTER TABLE IF EXISTS ONLY public.triage_desk_record DROP CONSTRAINT IF EXISTS triage_desk_record_pkey;
ALTER TABLE IF EXISTS ONLY public.settle_category DROP CONSTRAINT IF EXISTS settle_category_pkey;
ALTER TABLE IF EXISTS ONLY public.schedule_plan DROP CONSTRAINT IF EXISTS schedule_plan_pkey;
ALTER TABLE IF EXISTS ONLY public.schedule_adjust_request DROP CONSTRAINT IF EXISTS schedule_adjust_request_pkey;
ALTER TABLE IF EXISTS ONLY public.schedule_adjust_log DROP CONSTRAINT IF EXISTS schedule_adjust_log_pkey;
ALTER TABLE IF EXISTS ONLY public.register DROP CONSTRAINT IF EXISTS register_pkey;
ALTER TABLE IF EXISTS ONLY public.regist_level DROP CONSTRAINT IF EXISTS regist_level_pkey;
ALTER TABLE IF EXISTS ONLY public.prescription DROP CONSTRAINT IF EXISTS prescription_pkey;
ALTER TABLE IF EXISTS ONLY public.patient DROP CONSTRAINT IF EXISTS patient_pkey;
ALTER TABLE IF EXISTS ONLY public.patient_balance_transaction DROP CONSTRAINT IF EXISTS patient_balance_transaction_pkey;
ALTER TABLE IF EXISTS ONLY public.medical_technology DROP CONSTRAINT IF EXISTS medical_technology_pkey;
ALTER TABLE IF EXISTS ONLY public.medical_record DROP CONSTRAINT IF EXISTS medical_record_pkey;
ALTER TABLE IF EXISTS ONLY public.medical_record_disease DROP CONSTRAINT IF EXISTS medical_record_disease_pkey;
ALTER TABLE IF EXISTS ONLY public.leave_request DROP CONSTRAINT IF EXISTS leave_request_pkey;
ALTER TABLE IF EXISTS ONLY public.inspection_request DROP CONSTRAINT IF EXISTS inspection_request_pkey;
ALTER TABLE IF EXISTS ONLY public.expense_record DROP CONSTRAINT IF EXISTS expense_record_pkey;
ALTER TABLE IF EXISTS ONLY public.employee DROP CONSTRAINT IF EXISTS employee_pkey;
ALTER TABLE IF EXISTS ONLY public.drug_info DROP CONSTRAINT IF EXISTS drug_info_pkey;
ALTER TABLE IF EXISTS ONLY public.doctor_schedule DROP CONSTRAINT IF EXISTS doctor_schedule_pkey;
ALTER TABLE IF EXISTS ONLY public.disposal_request DROP CONSTRAINT IF EXISTS disposal_request_pkey;
ALTER TABLE IF EXISTS ONLY public.disease DROP CONSTRAINT IF EXISTS disease_pkey;
ALTER TABLE IF EXISTS ONLY public.department DROP CONSTRAINT IF EXISTS department_pkey;
ALTER TABLE IF EXISTS ONLY public.check_request DROP CONSTRAINT IF EXISTS check_request_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_triage_record DROP CONSTRAINT IF EXISTS ai_triage_record_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_prescription_review DROP CONSTRAINT IF EXISTS ai_prescription_review_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_medical_record_log DROP CONSTRAINT IF EXISTS ai_medical_record_log_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_record DROP CONSTRAINT IF EXISTS ai_follow_up_record_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_follow_up_plan DROP CONSTRAINT IF EXISTS ai_follow_up_plan_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_exam_suggestion DROP CONSTRAINT IF EXISTS ai_exam_suggestion_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_exam_analysis DROP CONSTRAINT IF EXISTS ai_exam_analysis_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_diagnosis_suggestion DROP CONSTRAINT IF EXISTS ai_diagnosis_suggestion_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_consultation_record DROP CONSTRAINT IF EXISTS ai_consultation_record_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.triage_desk_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settle_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schedule_plan ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schedule_adjust_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schedule_adjust_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.register ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.regist_level ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.prescription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.patient_balance_transaction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.patient ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.medical_technology ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.medical_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.leave_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inspection_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expense_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.employee ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.drug_info ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.doctor_schedule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.disposal_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.disease ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.department ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.check_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_triage_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_prescription_review ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_medical_record_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_follow_up_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_follow_up_plan ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_exam_suggestion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_exam_analysis ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_diagnosis_suggestion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ai_consultation_record ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_patient_managed;
DROP SEQUENCE IF EXISTS public.triage_desk_record_id_seq;
DROP TABLE IF EXISTS public.triage_desk_record;
DROP SEQUENCE IF EXISTS public.settle_category_id_seq;
DROP TABLE IF EXISTS public.settle_category;
DROP SEQUENCE IF EXISTS public.schedule_plan_id_seq;
DROP TABLE IF EXISTS public.schedule_plan;
DROP SEQUENCE IF EXISTS public.schedule_adjust_request_id_seq;
DROP TABLE IF EXISTS public.schedule_adjust_request;
DROP SEQUENCE IF EXISTS public.schedule_adjust_log_id_seq;
DROP TABLE IF EXISTS public.schedule_adjust_log;
DROP SEQUENCE IF EXISTS public.register_id_seq;
DROP TABLE IF EXISTS public.register;
DROP SEQUENCE IF EXISTS public.regist_level_id_seq;
DROP TABLE IF EXISTS public.regist_level;
DROP SEQUENCE IF EXISTS public.prescription_id_seq;
DROP TABLE IF EXISTS public.prescription;
DROP SEQUENCE IF EXISTS public.patient_id_seq;
DROP SEQUENCE IF EXISTS public.patient_balance_transaction_id_seq;
DROP TABLE IF EXISTS public.patient_balance_transaction;
DROP TABLE IF EXISTS public.patient;
DROP SEQUENCE IF EXISTS public.medical_technology_id_seq;
DROP TABLE IF EXISTS public.medical_technology;
DROP SEQUENCE IF EXISTS public.medical_record_id_seq;
DROP TABLE IF EXISTS public.medical_record_disease;
DROP TABLE IF EXISTS public.medical_record;
DROP SEQUENCE IF EXISTS public.leave_request_id_seq;
DROP TABLE IF EXISTS public.leave_request;
DROP SEQUENCE IF EXISTS public.inspection_request_id_seq;
DROP TABLE IF EXISTS public.inspection_request;
DROP SEQUENCE IF EXISTS public.expense_record_id_seq;
DROP TABLE IF EXISTS public.expense_record;
DROP SEQUENCE IF EXISTS public.employee_id_seq;
DROP TABLE IF EXISTS public.employee;
DROP SEQUENCE IF EXISTS public.drug_info_id_seq;
DROP TABLE IF EXISTS public.drug_info;
DROP SEQUENCE IF EXISTS public.doctor_schedule_id_seq;
DROP TABLE IF EXISTS public.doctor_schedule;
DROP SEQUENCE IF EXISTS public.disposal_request_id_seq;
DROP TABLE IF EXISTS public.disposal_request;
DROP SEQUENCE IF EXISTS public.disease_id_seq;
DROP TABLE IF EXISTS public.disease;
DROP SEQUENCE IF EXISTS public.department_id_seq;
DROP TABLE IF EXISTS public.department;
DROP SEQUENCE IF EXISTS public.check_request_id_seq;
DROP TABLE IF EXISTS public.check_request;
DROP SEQUENCE IF EXISTS public.ai_triage_record_id_seq;
DROP TABLE IF EXISTS public.ai_triage_record;
DROP SEQUENCE IF EXISTS public.ai_prescription_review_id_seq;
DROP TABLE IF EXISTS public.ai_prescription_review;
DROP SEQUENCE IF EXISTS public.ai_medical_record_log_id_seq;
DROP TABLE IF EXISTS public.ai_medical_record_log;
DROP SEQUENCE IF EXISTS public.ai_follow_up_record_id_seq;
DROP TABLE IF EXISTS public.ai_follow_up_record;
DROP SEQUENCE IF EXISTS public.ai_follow_up_plan_id_seq;
DROP TABLE IF EXISTS public.ai_follow_up_plan;
DROP SEQUENCE IF EXISTS public.ai_exam_suggestion_id_seq;
DROP TABLE IF EXISTS public.ai_exam_suggestion;
DROP SEQUENCE IF EXISTS public.ai_exam_analysis_id_seq;
DROP TABLE IF EXISTS public.ai_exam_analysis;
DROP SEQUENCE IF EXISTS public.ai_diagnosis_suggestion_id_seq;
DROP TABLE IF EXISTS public.ai_diagnosis_suggestion;
DROP SEQUENCE IF EXISTS public.ai_consultation_record_id_seq;
DROP TABLE IF EXISTS public.ai_consultation_record;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_consultation_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_consultation_record (
    id integer NOT NULL,
    register_id integer NOT NULL,
    round_number integer DEFAULT 1 NOT NULL,
    ai_question text,
    patient_answer text,
    consultation_state character varying(16) DEFAULT 'in_progress'::character varying NOT NULL,
    chief_complaint character varying(512) DEFAULT NULL::character varying,
    symptom_duration character varying(128) DEFAULT NULL::character varying,
    history_summary text,
    allergy_summary text,
    medication_summary text,
    ai_summary text,
    suggested_exam text,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completion_time timestamp without time zone,
    model_id character varying(64) DEFAULT NULL::character varying,
    patient_id integer,
    session_uuid character varying(64),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_ai_consult_state CHECK (((consultation_state)::text = ANY ((ARRAY['in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.ai_consultation_record OWNER TO postgres;

--
-- Name: TABLE ai_consultation_record; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_consultation_record IS 'AI预问诊记录表（多轮对话）';


--
-- Name: COLUMN ai_consultation_record.patient_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_consultation_record.patient_id IS '患者ID，便于按患者查询预问诊列表';


--
-- Name: COLUMN ai_consultation_record.session_uuid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_consultation_record.session_uuid IS '会话UUID，同一会话的多轮对话共享';


--
-- Name: ai_consultation_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_consultation_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_consultation_record_id_seq OWNER TO postgres;

--
-- Name: ai_consultation_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_consultation_record_id_seq OWNED BY public.ai_consultation_record.id;


--
-- Name: ai_diagnosis_suggestion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_diagnosis_suggestion (
    id integer NOT NULL,
    register_id integer NOT NULL,
    disease_id integer,
    disease_name character varying(255) DEFAULT NULL::character varying,
    recommend_icd character varying(64) DEFAULT NULL::character varying,
    probability numeric(5,2) DEFAULT NULL::numeric,
    risk_level character varying(16) DEFAULT 'low'::character varying NOT NULL,
    treatment_direction text,
    diagnosis_basis text,
    is_adopted smallint DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_diagnosis_adopted CHECK ((is_adopted = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_ai_diagnosis_probability CHECK (((probability IS NULL) OR ((probability >= (0)::numeric) AND (probability <= (100)::numeric)))),
    CONSTRAINT chk_ai_diagnosis_risk CHECK (((risk_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


ALTER TABLE public.ai_diagnosis_suggestion OWNER TO postgres;

--
-- Name: TABLE ai_diagnosis_suggestion; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_diagnosis_suggestion IS 'AI辅助诊断建议表';


--
-- Name: COLUMN ai_diagnosis_suggestion.probability; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_diagnosis_suggestion.probability IS '疾病概率百分比，如85.50表示85.50%';


--
-- Name: ai_diagnosis_suggestion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_diagnosis_suggestion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_diagnosis_suggestion_id_seq OWNER TO postgres;

--
-- Name: ai_diagnosis_suggestion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_diagnosis_suggestion_id_seq OWNED BY public.ai_diagnosis_suggestion.id;


--
-- Name: ai_exam_analysis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_exam_analysis (
    id integer NOT NULL,
    register_id integer NOT NULL,
    check_request_id integer,
    inspection_request_id integer,
    analysis_type character varying(16) NOT NULL,
    original_result text,
    abnormal_indicators text,
    risk_level character varying(16) DEFAULT 'normal'::character varying NOT NULL,
    analysis_report text,
    correlation_analysis text,
    is_viewed smallint DEFAULT 0 NOT NULL,
    analysis_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_exam_analysis_risk CHECK (((risk_level)::text = ANY ((ARRAY['normal'::character varying, 'attention'::character varying, 'warning'::character varying, 'danger'::character varying])::text[]))),
    CONSTRAINT chk_ai_exam_analysis_type CHECK (((analysis_type)::text = ANY ((ARRAY['check'::character varying, 'inspection'::character varying])::text[]))),
    CONSTRAINT chk_ai_exam_analysis_viewed CHECK ((is_viewed = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.ai_exam_analysis OWNER TO postgres;

--
-- Name: TABLE ai_exam_analysis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_exam_analysis IS 'AI检查/检验结果分析表';


--
-- Name: COLUMN ai_exam_analysis.abnormal_indicators; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_exam_analysis.abnormal_indicators IS '异常指标，JSON格式，如: [{"指标":"白细胞","值":"15.2","参考值":"4-10","单位":"10^9/L"}]';


--
-- Name: ai_exam_analysis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_exam_analysis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_exam_analysis_id_seq OWNER TO postgres;

--
-- Name: ai_exam_analysis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_exam_analysis_id_seq OWNED BY public.ai_exam_analysis.id;


--
-- Name: ai_exam_suggestion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_exam_suggestion (
    id integer NOT NULL,
    register_id integer NOT NULL,
    tech_id integer NOT NULL,
    tech_name character varying(64) DEFAULT NULL::character varying,
    suggest_type character varying(16) NOT NULL,
    suggest_reason text,
    priority integer DEFAULT 1 NOT NULL,
    is_adopted smallint DEFAULT 0 NOT NULL,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_exam_sug_adopted CHECK ((is_adopted = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_ai_exam_sug_priority CHECK ((priority = ANY (ARRAY[1, 2, 3]))),
    CONSTRAINT chk_ai_exam_sug_type CHECK (((suggest_type)::text = ANY ((ARRAY['check'::character varying, 'inspection'::character varying])::text[])))
);


ALTER TABLE public.ai_exam_suggestion OWNER TO postgres;

--
-- Name: TABLE ai_exam_suggestion; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_exam_suggestion IS 'AI检查/检验推荐表';


--
-- Name: ai_exam_suggestion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_exam_suggestion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_exam_suggestion_id_seq OWNER TO postgres;

--
-- Name: ai_exam_suggestion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_exam_suggestion_id_seq OWNED BY public.ai_exam_suggestion.id;


--
-- Name: ai_follow_up_plan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_follow_up_plan (
    id integer NOT NULL,
    register_id integer NOT NULL,
    prescription_id integer,
    follow_up_day integer,
    planned_date date,
    follow_up_type character varying(32) NOT NULL,
    content_template text,
    plan_status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_followup_status CHECK (((plan_status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT chk_ai_followup_type CHECK (((follow_up_type)::text = ANY ((ARRAY['medication'::character varying, 'side_effect'::character varying, 'recovery'::character varying, 'revisit'::character varying])::text[])))
);


ALTER TABLE public.ai_follow_up_plan OWNER TO postgres;

--
-- Name: TABLE ai_follow_up_plan; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_follow_up_plan IS 'AI用药随访计划表';


--
-- Name: COLUMN ai_follow_up_plan.follow_up_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_follow_up_plan.follow_up_type IS '随访类型: medication-用药跟踪, side_effect-副作用反馈, recovery-康复评估, revisit-复诊提醒';


--
-- Name: ai_follow_up_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_follow_up_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_follow_up_plan_id_seq OWNER TO postgres;

--
-- Name: ai_follow_up_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_follow_up_plan_id_seq OWNED BY public.ai_follow_up_plan.id;


--
-- Name: ai_follow_up_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_follow_up_record (
    id integer NOT NULL,
    follow_up_plan_id integer NOT NULL,
    register_id integer NOT NULL,
    is_on_time smallint,
    side_effect text,
    has_side_effect smallint,
    symptom_relief character varying(32) DEFAULT NULL::character varying,
    need_revisit smallint,
    patient_feedback text,
    ai_assessment text,
    ai_advice text,
    follow_up_time timestamp without time zone,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_fur_ontime CHECK (((is_on_time IS NULL) OR (is_on_time = ANY (ARRAY[0, 1])))),
    CONSTRAINT chk_ai_fur_relief CHECK (((symptom_relief IS NULL) OR ((symptom_relief)::text = ANY ((ARRAY['relieved'::character varying, 'partial'::character varying, 'unchanged'::character varying, 'worsened'::character varying])::text[])))),
    CONSTRAINT chk_ai_fur_revisit CHECK (((need_revisit IS NULL) OR (need_revisit = ANY (ARRAY[0, 1])))),
    CONSTRAINT chk_ai_fur_side_effect CHECK (((has_side_effect IS NULL) OR (has_side_effect = ANY (ARRAY[0, 1]))))
);


ALTER TABLE public.ai_follow_up_record OWNER TO postgres;

--
-- Name: TABLE ai_follow_up_record; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_follow_up_record IS 'AI随访反馈记录表';


--
-- Name: ai_follow_up_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_follow_up_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_follow_up_record_id_seq OWNER TO postgres;

--
-- Name: ai_follow_up_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_follow_up_record_id_seq OWNED BY public.ai_follow_up_record.id;


--
-- Name: ai_medical_record_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_medical_record_log (
    id integer NOT NULL,
    register_id integer NOT NULL,
    medical_record_id integer,
    source_type character varying(32) NOT NULL,
    ai_readme text,
    ai_present text,
    ai_history text,
    ai_allergy text,
    ai_physique text,
    ai_diagnosis text,
    is_adopted smallint DEFAULT 0 NOT NULL,
    doctor_modification text,
    generation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_mrlog_adopted CHECK ((is_adopted = ANY (ARRAY[0, 1, 2]))),
    CONSTRAINT chk_ai_mrlog_source CHECK (((source_type)::text = ANY ((ARRAY['consultation'::character varying, 'dictation'::character varying, 'exam'::character varying])::text[])))
);


ALTER TABLE public.ai_medical_record_log OWNER TO postgres;

--
-- Name: TABLE ai_medical_record_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_medical_record_log IS 'AI病历生成日志表';


--
-- Name: COLUMN ai_medical_record_log.doctor_modification; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_medical_record_log.doctor_modification IS '医生修改内容，JSON格式记录被修改的字段和修改前后值';


--
-- Name: ai_medical_record_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_medical_record_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_medical_record_log_id_seq OWNER TO postgres;

--
-- Name: ai_medical_record_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_medical_record_log_id_seq OWNED BY public.ai_medical_record_log.id;


--
-- Name: ai_prescription_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_prescription_review (
    id integer NOT NULL,
    register_id integer NOT NULL,
    prescription_id integer NOT NULL,
    review_result character varying(16) NOT NULL,
    drug_conflict text,
    allergy_risk text,
    duplicate_drug text,
    dosage_check text,
    risk_score integer DEFAULT 0 NOT NULL,
    risk_details text,
    doctor_action character varying(16) DEFAULT NULL::character varying,
    review_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_review_action CHECK (((doctor_action IS NULL) OR ((doctor_action)::text = ANY ((ARRAY['accepted'::character varying, 'overridden'::character varying])::text[])))),
    CONSTRAINT chk_ai_review_result CHECK (((review_result)::text = ANY ((ARRAY['passed'::character varying, 'warning'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT chk_ai_review_score CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.ai_prescription_review OWNER TO postgres;

--
-- Name: TABLE ai_prescription_review; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_prescription_review IS 'AI处方审核表';


--
-- Name: COLUMN ai_prescription_review.risk_score; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_prescription_review.risk_score IS '综合风险评分0-100，0无风险，100极高风险';


--
-- Name: ai_prescription_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_prescription_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_prescription_review_id_seq OWNER TO postgres;

--
-- Name: ai_prescription_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_prescription_review_id_seq OWNED BY public.ai_prescription_review.id;


--
-- Name: ai_triage_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_triage_record (
    id integer NOT NULL,
    patient_name character varying(64) DEFAULT NULL::character varying,
    patient_age integer,
    patient_gender character varying(6) DEFAULT NULL::character varying,
    symptom_description text NOT NULL,
    recommend_dept_id integer,
    recommend_dept_name character varying(64) DEFAULT NULL::character varying,
    recommend_doctor_id integer,
    recommend_doctor_name character varying(64) DEFAULT NULL::character varying,
    risk_level character varying(16) DEFAULT 'normal'::character varying NOT NULL,
    is_priority smallint DEFAULT 0 NOT NULL,
    ai_analysis text,
    register_id integer,
    triage_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id character varying(64) DEFAULT NULL::character varying,
    CONSTRAINT chk_ai_triage_gender CHECK (((patient_gender IS NULL) OR ((patient_gender)::text = ANY ((ARRAY['男'::character varying, '女'::character varying])::text[])))),
    CONSTRAINT chk_ai_triage_priority CHECK ((is_priority = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_ai_triage_risk CHECK (((risk_level)::text = ANY ((ARRAY['normal'::character varying, 'low'::character varying, 'medium'::character varying, 'urgent'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.ai_triage_record OWNER TO postgres;

--
-- Name: TABLE ai_triage_record; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ai_triage_record IS 'AI导诊记录表';


--
-- Name: COLUMN ai_triage_record.register_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ai_triage_record.register_id IS '关联挂号ID，患者实际挂号后回填';


--
-- Name: ai_triage_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_triage_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_triage_record_id_seq OWNER TO postgres;

--
-- Name: ai_triage_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_triage_record_id_seq OWNED BY public.ai_triage_record.id;


--
-- Name: check_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.check_request (
    id integer NOT NULL,
    register_id integer NOT NULL,
    medical_technology_id integer NOT NULL,
    check_info character varying(512) DEFAULT NULL::character varying,
    check_position character varying(255) DEFAULT NULL::character varying,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    check_employee_id integer,
    inputcheck_employee_id integer,
    check_time timestamp without time zone,
    check_result character varying(512) DEFAULT NULL::character varying,
    check_state character varying(64) DEFAULT '待检查'::character varying NOT NULL,
    check_remark character varying(512) DEFAULT NULL::character varying,
    CONSTRAINT chk_check_request_state CHECK (((check_state)::text = ANY ((ARRAY['待检查'::character varying, '检查中'::character varying, '已完成'::character varying])::text[])))
);


ALTER TABLE public.check_request OWNER TO postgres;

--
-- Name: TABLE check_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.check_request IS '检查申请表';


--
-- Name: COLUMN check_request.check_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.check_request.check_state IS '状态: 待检查 → 检查中 → 已完成';


--
-- Name: check_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.check_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.check_request_id_seq OWNER TO postgres;

--
-- Name: check_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.check_request_id_seq OWNED BY public.check_request.id;


--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    id integer NOT NULL,
    dept_code character varying(64) NOT NULL,
    dept_name character varying(64) NOT NULL,
    dept_type character varying(64) DEFAULT NULL::character varying,
    delmark smallint DEFAULT 1 NOT NULL,
    dept_description text,
    CONSTRAINT chk_department_delmark CHECK ((delmark = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: TABLE department; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.department IS '科室表';


--
-- Name: COLUMN department.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.id IS '主键ID';


--
-- Name: COLUMN department.dept_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.dept_code IS '科室编码，如: SJNK(神经内科)';


--
-- Name: COLUMN department.dept_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.dept_name IS '科室名称';


--
-- Name: COLUMN department.dept_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.dept_type IS '科室类型: 临床科室、医技科室等';


--
-- Name: COLUMN department.delmark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.delmark IS '生效标记: 1-正常, 0-已删除';


--
-- Name: COLUMN department.dept_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.department.dept_description IS '科室简介，用于患者端科室导航展示';


--
-- Name: department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.department_id_seq OWNER TO postgres;

--
-- Name: department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.department_id_seq OWNED BY public.department.id;


--
-- Name: disease; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.disease (
    id integer NOT NULL,
    disease_code character varying(64) DEFAULT NULL::character varying,
    disease_name character varying(255) NOT NULL,
    diseaseicd character varying(64) DEFAULT NULL::character varying,
    disease_category character varying(64) DEFAULT NULL::character varying
);


ALTER TABLE public.disease OWNER TO postgres;

--
-- Name: TABLE disease; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.disease IS '疾病字典表';


--
-- Name: COLUMN disease.diseaseicd; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.disease.diseaseicd IS '国际ICD编码，如: G43.9(偏头痛)';


--
-- Name: disease_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.disease_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.disease_id_seq OWNER TO postgres;

--
-- Name: disease_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.disease_id_seq OWNED BY public.disease.id;


--
-- Name: disposal_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.disposal_request (
    id integer NOT NULL,
    register_id integer NOT NULL,
    medical_technology_id integer NOT NULL,
    disposal_info character varying(512) DEFAULT NULL::character varying,
    disposal_position character varying(255) DEFAULT NULL::character varying,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    disposal_employee_id integer,
    inputdisposal_employee_id integer,
    disposal_time timestamp without time zone,
    disposal_result character varying(512) DEFAULT NULL::character varying,
    disposal_state character varying(64) DEFAULT '待处置'::character varying NOT NULL,
    disposal_remark character varying(512) DEFAULT NULL::character varying,
    CONSTRAINT chk_disposal_state CHECK (((disposal_state)::text = ANY ((ARRAY['待处置'::character varying, '处置中'::character varying, '已完成'::character varying])::text[])))
);


ALTER TABLE public.disposal_request OWNER TO postgres;

--
-- Name: TABLE disposal_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.disposal_request IS '处置申请表';


--
-- Name: disposal_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.disposal_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.disposal_request_id_seq OWNER TO postgres;

--
-- Name: disposal_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.disposal_request_id_seq OWNED BY public.disposal_request.id;


--
-- Name: doctor_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_schedule (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    physician_id integer NOT NULL,
    department_id integer NOT NULL,
    work_date date NOT NULL,
    time_slot character varying(6) NOT NULL,
    regist_level_id integer NOT NULL,
    total_quota integer NOT NULL,
    used_quota integer DEFAULT 0 NOT NULL,
    available_quota integer NOT NULL,
    price numeric(8,2) NOT NULL,
    status character varying(16) DEFAULT '正常'::character varying NOT NULL,
    ai_suggestion character varying(255) DEFAULT NULL::character varying,
    modified boolean DEFAULT false NOT NULL,
    modify_remark character varying(255) DEFAULT NULL::character varying,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delmark smallint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_ds_status CHECK (((status)::text = ANY ((ARRAY['正常'::character varying, '停诊'::character varying, '满诊'::character varying, '替班'::character varying])::text[]))),
    CONSTRAINT chk_ds_time_slot CHECK (((time_slot)::text = ANY ((ARRAY['上午'::character varying, '下午'::character varying, '晚上'::character varying])::text[])))
);


ALTER TABLE public.doctor_schedule OWNER TO postgres;

--
-- Name: TABLE doctor_schedule; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.doctor_schedule IS '医生出诊明细表';


--
-- Name: COLUMN doctor_schedule.physician_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.doctor_schedule.physician_id IS '出诊医生ID';


--
-- Name: COLUMN doctor_schedule.time_slot; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.doctor_schedule.time_slot IS '时段：上午/下午/晚上';


--
-- Name: doctor_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctor_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_schedule_id_seq OWNER TO postgres;

--
-- Name: doctor_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctor_schedule_id_seq OWNED BY public.doctor_schedule.id;


--
-- Name: drug_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.drug_info (
    id integer NOT NULL,
    drug_code character varying(255) NOT NULL,
    drug_name character varying(255) NOT NULL,
    drug_format character varying(255) DEFAULT NULL::character varying,
    drug_unit character varying(16) DEFAULT NULL::character varying,
    manufacturer character varying(255) DEFAULT NULL::character varying,
    drug_dosage character varying(64) DEFAULT NULL::character varying,
    drug_type character varying(64) DEFAULT NULL::character varying,
    drug_price numeric(8,2) DEFAULT 0.00 NOT NULL,
    mnemonic_code character varying(255) DEFAULT NULL::character varying,
    creation_date date DEFAULT CURRENT_DATE,
    name character varying(255),
    generic_name character varying(255),
    brand_name character varying(255),
    specification character varying(255),
    dosage_form character varying(64),
    unit character varying(16),
    approval_number character varying(255),
    price numeric(8,2) DEFAULT 0.00 NOT NULL,
    stock_quantity integer DEFAULT 100 NOT NULL,
    low_stock_threshold integer DEFAULT 20 NOT NULL,
    storage_conditions character varying(255),
    instructions text,
    contraindications text,
    adverse_reactions text,
    status smallint DEFAULT 1 NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_drug_info_price_new CHECK ((price >= (0)::numeric)),
    CONSTRAINT chk_drug_info_status CHECK ((status = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_drug_price CHECK ((drug_price >= (0)::numeric))
);


ALTER TABLE public.drug_info OWNER TO postgres;

--
-- Name: TABLE drug_info; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.drug_info IS '药品信息表';


--
-- Name: COLUMN drug_info.mnemonic_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.drug_info.mnemonic_code IS '拼音助记码，用于快速搜索';


--
-- Name: drug_info_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.drug_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drug_info_id_seq OWNER TO postgres;

--
-- Name: drug_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.drug_info_id_seq OWNED BY public.drug_info.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    deptment_id integer,
    regist_level_id integer,
    realname character varying(64) NOT NULL,
    password character varying(64) NOT NULL,
    delmark smallint DEFAULT 1 NOT NULL,
    CONSTRAINT chk_employee_delmark CHECK ((delmark = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: TABLE employee; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.employee IS '医院员工表';


--
-- Name: COLUMN employee.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee.password IS '密码（BCrypt加密存储，禁止明文）';


--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_id_seq OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: expense_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expense_record (
    id bigint NOT NULL,
    register_id integer NOT NULL,
    patient_id integer,
    patient_name character varying(64),
    category_id integer,
    category_name character varying(64),
    item_id integer,
    item_name character varying(255),
    item_code character varying(64),
    quantity integer DEFAULT 1,
    unit_price numeric(10,2) DEFAULT 0.00,
    total_amount numeric(10,2) DEFAULT 0.00,
    status smallint DEFAULT 0 NOT NULL,
    pay_time timestamp without time zone,
    refund_time timestamp without time zone,
    operator_id integer,
    operator_name character varying(64),
    remark character varying(255),
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.expense_record OWNER TO postgres;

--
-- Name: TABLE expense_record; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.expense_record IS '费用记录表';


--
-- Name: COLUMN expense_record.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.expense_record.status IS '费用状态: 0-待缴费, 1-已缴费, 2-已退款, 3-已作废';


--
-- Name: expense_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expense_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_record_id_seq OWNER TO postgres;

--
-- Name: expense_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expense_record_id_seq OWNED BY public.expense_record.id;


--
-- Name: inspection_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_request (
    id integer NOT NULL,
    register_id integer NOT NULL,
    medical_technology_id integer NOT NULL,
    inspection_info character varying(512) DEFAULT NULL::character varying,
    inspection_position character varying(255) DEFAULT NULL::character varying,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    inspection_employee_id integer,
    inputinspection_employee_id integer,
    inspection_time timestamp without time zone,
    inspection_result character varying(512) DEFAULT NULL::character varying,
    inspection_state character varying(64) DEFAULT '待检验'::character varying NOT NULL,
    inspection_remark character varying(512) DEFAULT NULL::character varying,
    CONSTRAINT chk_inspection_state CHECK (((inspection_state)::text = ANY ((ARRAY['待检验'::character varying, '检验中'::character varying, '已完成'::character varying])::text[])))
);


ALTER TABLE public.inspection_request OWNER TO postgres;

--
-- Name: TABLE inspection_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.inspection_request IS '检验申请表';


--
-- Name: inspection_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inspection_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inspection_request_id_seq OWNER TO postgres;

--
-- Name: inspection_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inspection_request_id_seq OWNED BY public.inspection_request.id;


--
-- Name: leave_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_request (
    id integer NOT NULL,
    physician_id integer NOT NULL,
    leave_date date NOT NULL,
    time_slot character varying(6) DEFAULT NULL::character varying,
    leave_type character varying(32) NOT NULL,
    reason text,
    ai_parsed_date date,
    ai_parsed_slot character varying(6) DEFAULT NULL::character varying,
    ai_confidence numeric(3,2) DEFAULT NULL::numeric,
    status character varying(16) DEFAULT '待审批'::character varying NOT NULL,
    approver_id integer,
    approval_time timestamp without time zone,
    auto_processed boolean DEFAULT false NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delmark smallint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_lr_slot CHECK (((time_slot IS NULL) OR ((time_slot)::text = ANY ((ARRAY['上午'::character varying, '下午'::character varying, '全天'::character varying])::text[])))),
    CONSTRAINT chk_lr_status CHECK (((status)::text = ANY ((ARRAY['待审批'::character varying, '已批准'::character varying, '已拒绝'::character varying, '已处理'::character varying])::text[]))),
    CONSTRAINT chk_lr_type CHECK (((leave_type)::text = ANY ((ARRAY['事假'::character varying, '病假'::character varying, '公假'::character varying, '其他'::character varying])::text[])))
);


ALTER TABLE public.leave_request OWNER TO postgres;

--
-- Name: TABLE leave_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.leave_request IS '医生请假申请表';


--
-- Name: COLUMN leave_request.ai_parsed_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.leave_request.ai_parsed_date IS 'AI解析后的日期';


--
-- Name: COLUMN leave_request.ai_confidence; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.leave_request.ai_confidence IS 'AI解析置信度';


--
-- Name: COLUMN leave_request.auto_processed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.leave_request.auto_processed IS '是否已自动处理（生成调整方案）';


--
-- Name: leave_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leave_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leave_request_id_seq OWNER TO postgres;

--
-- Name: leave_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leave_request_id_seq OWNED BY public.leave_request.id;


--
-- Name: medical_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medical_record (
    id integer NOT NULL,
    register_id integer NOT NULL,
    readme character varying(512) DEFAULT NULL::character varying,
    present character varying(512) DEFAULT NULL::character varying,
    present_treat character varying(512) DEFAULT NULL::character varying,
    history character varying(512) DEFAULT NULL::character varying,
    allergy character varying(512) DEFAULT NULL::character varying,
    physique character varying(512) DEFAULT NULL::character varying,
    proposal character varying(512) DEFAULT NULL::character varying,
    careful character varying(512) DEFAULT NULL::character varying,
    diagnosis character varying(512) DEFAULT NULL::character varying,
    cure character varying(512) DEFAULT NULL::character varying
);


ALTER TABLE public.medical_record OWNER TO postgres;

--
-- Name: TABLE medical_record; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.medical_record IS '患者病历表';


--
-- Name: medical_record_disease; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medical_record_disease (
    medical_record_id integer NOT NULL,
    disease_id integer NOT NULL
);


ALTER TABLE public.medical_record_disease OWNER TO postgres;

--
-- Name: TABLE medical_record_disease; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.medical_record_disease IS '病历-疾病关联表（多对多）';


--
-- Name: medical_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medical_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medical_record_id_seq OWNER TO postgres;

--
-- Name: medical_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medical_record_id_seq OWNED BY public.medical_record.id;


--
-- Name: medical_technology; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medical_technology (
    id integer NOT NULL,
    tech_code character varying(64) NOT NULL,
    tech_name character varying(64) NOT NULL,
    tech_format character varying(64) DEFAULT NULL::character varying,
    tech_price numeric(8,2) DEFAULT 0.00 NOT NULL,
    tech_type character varying(64) NOT NULL,
    price_type character varying(64) DEFAULT NULL::character varying,
    deptment_id integer,
    name character varying(255),
    code character varying(64),
    type character varying(64),
    department_id integer,
    department_name character varying(64),
    price numeric(8,2) DEFAULT 0.00 NOT NULL,
    specimen_type character varying(64),
    container character varying(64),
    instructions text,
    preparation text,
    turnaround_time integer,
    status smallint DEFAULT 1 NOT NULL,
    description text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_medtech_price CHECK ((tech_price >= (0)::numeric)),
    CONSTRAINT chk_medtech_price_new CHECK ((price >= (0)::numeric)),
    CONSTRAINT chk_medtech_status CHECK ((status = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_medtech_type CHECK (((tech_type)::text = ANY ((ARRAY['check'::character varying, 'inspection'::character varying, 'disposal'::character varying])::text[])))
);


ALTER TABLE public.medical_technology OWNER TO postgres;

--
-- Name: TABLE medical_technology; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.medical_technology IS '医技项目表（检查/检验/处置统一目录）';


--
-- Name: COLUMN medical_technology.tech_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medical_technology.tech_type IS '项目类型: check-检查, inspection-检验, disposal-处置';


--
-- Name: medical_technology_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medical_technology_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medical_technology_id_seq OWNER TO postgres;

--
-- Name: medical_technology_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medical_technology_id_seq OWNED BY public.medical_technology.id;


--
-- Name: patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient (
    id integer NOT NULL,
    real_name character varying(64) DEFAULT ''::character varying NOT NULL,
    id_card character varying(18),
    gender character varying(6),
    birthdate date,
    phone character varying(20) DEFAULT NULL::character varying,
    avatar character varying(255) DEFAULT NULL::character varying,
    home_address character varying(255) DEFAULT NULL::character varying,
    allergy_history character varying(512) DEFAULT NULL::character varying,
    delmark smallint DEFAULT 1 NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    account_balance numeric(10,2) DEFAULT 0.00 NOT NULL,
    CONSTRAINT chk_patient_delmark CHECK ((delmark = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.patient OWNER TO postgres;

--
-- Name: TABLE patient; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.patient IS '患者档案表';


--
-- Name: COLUMN patient.id_card; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient.id_card IS '身份证号，唯一';


--
-- Name: COLUMN patient.allergy_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient.allergy_history IS '过敏史';


--
-- Name: COLUMN patient.account_balance; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient.account_balance IS '患者账户余额';


--
-- Name: patient_balance_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_balance_transaction (
    id bigint NOT NULL,
    transaction_no character varying(64) NOT NULL,
    patient_id integer NOT NULL,
    transaction_type character varying(16) NOT NULL,
    amount numeric(10,2) NOT NULL,
    balance_before numeric(10,2) NOT NULL,
    balance_after numeric(10,2) NOT NULL,
    business_type character varying(64) DEFAULT NULL::character varying,
    business_id bigint,
    operator_id bigint,
    operator_name character varying(64) DEFAULT NULL::character varying,
    remark character varying(255) DEFAULT NULL::character varying,
    transaction_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_patient_balance_transaction_amount CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_patient_balance_transaction_balance CHECK (((balance_before >= (0)::numeric) AND (balance_after >= (0)::numeric))),
    CONSTRAINT chk_patient_balance_transaction_type CHECK (((transaction_type)::text = ANY ((ARRAY['RECHARGE'::character varying, 'DEDUCT'::character varying, 'REFUND'::character varying])::text[])))
);


ALTER TABLE public.patient_balance_transaction OWNER TO postgres;

--
-- Name: TABLE patient_balance_transaction; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.patient_balance_transaction IS '患者余额流水表';


--
-- Name: COLUMN patient_balance_transaction.transaction_no; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.transaction_no IS '唯一交易流水号';


--
-- Name: COLUMN patient_balance_transaction.transaction_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.transaction_type IS '交易类型: RECHARGE-充值, DEDUCT-扣款, REFUND-退款';


--
-- Name: COLUMN patient_balance_transaction.balance_before; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.balance_before IS '变更前余额';


--
-- Name: COLUMN patient_balance_transaction.balance_after; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.balance_after IS '变更后余额';


--
-- Name: COLUMN patient_balance_transaction.business_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.business_type IS '业务类型，如 REGISTRATION';


--
-- Name: COLUMN patient_balance_transaction.business_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_balance_transaction.business_id IS '业务ID，如挂号单ID';


--
-- Name: patient_balance_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_balance_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_balance_transaction_id_seq OWNER TO postgres;

--
-- Name: patient_balance_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_balance_transaction_id_seq OWNED BY public.patient_balance_transaction.id;


--
-- Name: patient_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_id_seq OWNER TO postgres;

--
-- Name: patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_id_seq OWNED BY public.patient.id;


--
-- Name: prescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prescription (
    id integer NOT NULL,
    register_id integer NOT NULL,
    drug_id integer NOT NULL,
    drug_usage character varying(255) DEFAULT NULL::character varying,
    drug_number character varying(255) DEFAULT NULL::character varying,
    creation_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    drug_state character varying(64) DEFAULT '未发'::character varying NOT NULL,
    CONSTRAINT chk_prescription_state CHECK (((drug_state)::text = ANY ((ARRAY['未发'::character varying, '已发'::character varying, '已退'::character varying])::text[])))
);


ALTER TABLE public.prescription OWNER TO postgres;

--
-- Name: TABLE prescription; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.prescription IS '处方表（每条记录对应一个药品）';


--
-- Name: COLUMN prescription.drug_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prescription.drug_state IS '状态: 未发 → 已发，或 未发 → 已退';


--
-- Name: prescription_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prescription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_id_seq OWNER TO postgres;

--
-- Name: prescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prescription_id_seq OWNED BY public.prescription.id;


--
-- Name: regist_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regist_level (
    id integer NOT NULL,
    regist_code character varying(64) NOT NULL,
    regist_name character varying(64) NOT NULL,
    regist_fee numeric(8,2) DEFAULT 0.00 NOT NULL,
    regist_quota integer DEFAULT 0,
    sequence_no integer DEFAULT 0,
    delmark smallint DEFAULT 1 NOT NULL,
    CONSTRAINT chk_regist_level_delmark CHECK ((delmark = ANY (ARRAY[0, 1]))),
    CONSTRAINT chk_regist_level_fee CHECK ((regist_fee >= (0)::numeric)),
    CONSTRAINT chk_regist_level_quota CHECK ((regist_quota >= 0))
);


ALTER TABLE public.regist_level OWNER TO postgres;

--
-- Name: TABLE regist_level; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.regist_level IS '挂号级别表';


--
-- Name: COLUMN regist_level.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.id IS '主键ID';


--
-- Name: COLUMN regist_level.regist_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.regist_code IS '号别编码';


--
-- Name: COLUMN regist_level.regist_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.regist_name IS '号别名称';


--
-- Name: COLUMN regist_level.regist_fee; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.regist_fee IS '挂号费（元）';


--
-- Name: COLUMN regist_level.regist_quota; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.regist_quota IS '每半天挂号限额';


--
-- Name: COLUMN regist_level.sequence_no; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.sequence_no IS '显示顺序号';


--
-- Name: COLUMN regist_level.delmark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.regist_level.delmark IS '生效标记: 1-正常, 0-已删除';


--
-- Name: regist_level_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.regist_level_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regist_level_id_seq OWNER TO postgres;

--
-- Name: regist_level_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.regist_level_id_seq OWNED BY public.regist_level.id;


--
-- Name: register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.register (
    id integer NOT NULL,
    case_number character varying(64) NOT NULL,
    real_name character varying(64) NOT NULL,
    gender character varying(6) DEFAULT NULL::character varying,
    card_number character varying(18) DEFAULT NULL::character varying,
    birthdate date,
    age integer,
    age_type character varying(6) DEFAULT NULL::character varying,
    home_address character varying(128) DEFAULT NULL::character varying,
    visit_date timestamp without time zone,
    noon character varying(6) DEFAULT NULL::character varying,
    deptment_id integer NOT NULL,
    employee_id integer NOT NULL,
    regist_level_id integer NOT NULL,
    settle_category_id integer,
    is_book character varying(2) DEFAULT '否'::character varying,
    regist_method character varying(10) DEFAULT NULL::character varying,
    regist_money numeric(8,2) DEFAULT 0.00,
    visit_state smallint DEFAULT 1 NOT NULL,
    patient_id bigint,
    scheduling_id bigint,
    check_in_time timestamp without time zone,
    CONSTRAINT chk_register_gender CHECK (((gender IS NULL) OR ((gender)::text = ANY ((ARRAY['男'::character varying, '女'::character varying])::text[])))),
    CONSTRAINT chk_register_is_book CHECK (((is_book)::text = ANY ((ARRAY['是'::character varying, '否'::character varying])::text[]))),
    CONSTRAINT chk_register_noon CHECK (((noon IS NULL) OR ((noon)::text = ANY ((ARRAY['上午'::character varying, '下午'::character varying, '晚上'::character varying])::text[])))),
    CONSTRAINT chk_register_regist_money CHECK ((regist_money >= (0)::numeric)),
    CONSTRAINT chk_register_visit_state CHECK ((visit_state = ANY (ARRAY[1, 2, 3, 4, 5])))
);


ALTER TABLE public.register OWNER TO postgres;

--
-- Name: TABLE register; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.register IS '患者历次挂号信息表';


--
-- Name: COLUMN register.case_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.register.case_number IS '病历号，同一患者多次挂号共用同一病历号';


--
-- Name: COLUMN register.visit_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.register.visit_state IS '看诊状态: 1-已挂号, 2-医生接诊, 3-看诊结束, 4-已退号';


--
-- Name: COLUMN register.patient_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.register.patient_id IS '患者ID';


--
-- Name: COLUMN register.scheduling_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.register.scheduling_id IS '排班ID';


--
-- Name: COLUMN register.check_in_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.register.check_in_time IS '报到时间: NULL表示未报到；非NULL表示已扫码报到进入候诊队列';


--
-- Name: register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.register_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.register_id_seq OWNER TO postgres;

--
-- Name: register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.register_id_seq OWNED BY public.register.id;


--
-- Name: schedule_adjust_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_adjust_log (
    id integer NOT NULL,
    schedule_id integer NOT NULL,
    field_name character varying(32) NOT NULL,
    old_value character varying(255) DEFAULT NULL::character varying,
    new_value character varying(255) DEFAULT NULL::character varying,
    adjust_type character varying(16) NOT NULL,
    adjust_by integer NOT NULL,
    adjust_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    remark character varying(255) DEFAULT NULL::character varying,
    delmark smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.schedule_adjust_log OWNER TO postgres;

--
-- Name: TABLE schedule_adjust_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.schedule_adjust_log IS '排班调整日志表';


--
-- Name: COLUMN schedule_adjust_log.field_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.schedule_adjust_log.field_name IS '调整字段名';


--
-- Name: schedule_adjust_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_adjust_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_adjust_log_id_seq OWNER TO postgres;

--
-- Name: schedule_adjust_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_adjust_log_id_seq OWNED BY public.schedule_adjust_log.id;


--
-- Name: schedule_adjust_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_adjust_request (
    id integer NOT NULL,
    schedule_id integer NOT NULL,
    adjust_type character varying(16) NOT NULL,
    old_physician_id integer,
    new_physician_id integer,
    old_status character varying(16) DEFAULT NULL::character varying,
    new_status character varying(16) DEFAULT NULL::character varying,
    old_quota integer,
    new_quota integer,
    reason text,
    ai_suggestion text,
    affect_patients integer DEFAULT 0,
    triggered_by integer NOT NULL,
    status character varying(16) DEFAULT '待确认'::character varying NOT NULL,
    confirmed_by integer,
    confirm_time timestamp without time zone,
    confirm_remark character varying(255) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delmark smallint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_sar_status CHECK (((status)::text = ANY ((ARRAY['待确认'::character varying, '已确认'::character varying, '已驳回'::character varying])::text[]))),
    CONSTRAINT chk_sar_type CHECK (((adjust_type)::text = ANY ((ARRAY['leave_ai'::character varying, 'admin_urgent'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.schedule_adjust_request OWNER TO postgres;

--
-- Name: TABLE schedule_adjust_request; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.schedule_adjust_request IS '排班调整申请表';


--
-- Name: COLUMN schedule_adjust_request.adjust_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.schedule_adjust_request.adjust_type IS '调整类型：leave_ai-请假AI调整/admin_urgent-管理员紧急调整/system-系统调整';


--
-- Name: COLUMN schedule_adjust_request.affect_patients; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.schedule_adjust_request.affect_patients IS '预计影响患者数';


--
-- Name: schedule_adjust_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_adjust_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_adjust_request_id_seq OWNER TO postgres;

--
-- Name: schedule_adjust_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_adjust_request_id_seq OWNED BY public.schedule_adjust_request.id;


--
-- Name: schedule_plan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_plan (
    id integer NOT NULL,
    plan_name character varying(64) NOT NULL,
    department_id integer NOT NULL,
    plan_month character varying(7) NOT NULL,
    status character varying(16) DEFAULT '草稿'::character varying NOT NULL,
    ai_generated boolean DEFAULT false NOT NULL,
    ai_version integer,
    total_schedules integer DEFAULT 0,
    total_quota integer DEFAULT 0,
    created_by integer,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    published_time timestamp without time zone,
    published_by integer,
    delmark smallint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_sp_status CHECK (((status)::text = ANY ((ARRAY['草稿'::character varying, '待审核'::character varying, '已发布'::character varying])::text[])))
);


ALTER TABLE public.schedule_plan OWNER TO postgres;

--
-- Name: TABLE schedule_plan; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.schedule_plan IS '排班计划表，按月/按科室管理';


--
-- Name: COLUMN schedule_plan.plan_month; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.schedule_plan.plan_month IS '计划月份，格式：YYYY-MM';


--
-- Name: COLUMN schedule_plan.ai_generated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.schedule_plan.ai_generated IS '是否由AI生成';


--
-- Name: schedule_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_plan_id_seq OWNER TO postgres;

--
-- Name: schedule_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_plan_id_seq OWNED BY public.schedule_plan.id;


--
-- Name: settle_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settle_category (
    id integer NOT NULL,
    settle_code character varying(64) NOT NULL,
    settle_name character varying(64) NOT NULL,
    sequence_no integer DEFAULT 0,
    delmark smallint DEFAULT 1 NOT NULL,
    CONSTRAINT chk_settle_category_delmark CHECK ((delmark = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.settle_category OWNER TO postgres;

--
-- Name: TABLE settle_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.settle_category IS '结算类别表';


--
-- Name: settle_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settle_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settle_category_id_seq OWNER TO postgres;

--
-- Name: settle_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settle_category_id_seq OWNED BY public.settle_category.id;


--
-- Name: triage_desk_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.triage_desk_record (
    id bigint NOT NULL,
    patient_id integer,
    patient_name character varying(64),
    patient_phone character varying(20),
    symptoms text,
    ai_triage_result text,
    recommended_department_id integer,
    recommended_department character varying(64),
    recommended_physician_id integer,
    recommended_physician_name character varying(64),
    risk_level character varying(16),
    ai_analysis text,
    status smallint DEFAULT 0 NOT NULL,
    confirmed_department_id integer,
    confirmed_department character varying(64),
    confirmed_physician_id integer,
    confirmed_physician_name character varying(64),
    operator_id integer,
    operator_name character varying(64),
    confirm_remark character varying(255),
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    confirm_time timestamp without time zone
);


ALTER TABLE public.triage_desk_record OWNER TO postgres;

--
-- Name: triage_desk_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.triage_desk_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.triage_desk_record_id_seq OWNER TO postgres;

--
-- Name: triage_desk_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.triage_desk_record_id_seq OWNED BY public.triage_desk_record.id;


--
-- Name: user_patient_managed; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_patient_managed (
    user_id integer NOT NULL,
    patient_id integer NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    relation character varying(16)
);


ALTER TABLE public.user_patient_managed OWNER TO postgres;

--
-- Name: TABLE user_patient_managed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_patient_managed IS '用户管理的患者列表（本人+家人）';


--
-- Name: COLUMN user_patient_managed.relation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_patient_managed.relation IS '账号与该患者的关系';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(64) NOT NULL,
    password character varying(255) NOT NULL,
    real_name character varying(64) DEFAULT NULL::character varying,
    email character varying(128) DEFAULT NULL::character varying,
    phone character varying(20) DEFAULT NULL::character varying,
    status integer DEFAULT 1 NOT NULL,
    user_type integer DEFAULT 6 NOT NULL,
    remark character varying(255) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_users_status CHECK ((status = ANY (ARRAY[1, 0, '-1'::integer])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: ai_consultation_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_consultation_record ALTER COLUMN id SET DEFAULT nextval('public.ai_consultation_record_id_seq'::regclass);


--
-- Name: ai_diagnosis_suggestion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_diagnosis_suggestion ALTER COLUMN id SET DEFAULT nextval('public.ai_diagnosis_suggestion_id_seq'::regclass);


--
-- Name: ai_exam_analysis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_analysis ALTER COLUMN id SET DEFAULT nextval('public.ai_exam_analysis_id_seq'::regclass);


--
-- Name: ai_exam_suggestion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_suggestion ALTER COLUMN id SET DEFAULT nextval('public.ai_exam_suggestion_id_seq'::regclass);


--
-- Name: ai_follow_up_plan id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_plan ALTER COLUMN id SET DEFAULT nextval('public.ai_follow_up_plan_id_seq'::regclass);


--
-- Name: ai_follow_up_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_record ALTER COLUMN id SET DEFAULT nextval('public.ai_follow_up_record_id_seq'::regclass);


--
-- Name: ai_medical_record_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_medical_record_log ALTER COLUMN id SET DEFAULT nextval('public.ai_medical_record_log_id_seq'::regclass);


--
-- Name: ai_prescription_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_prescription_review ALTER COLUMN id SET DEFAULT nextval('public.ai_prescription_review_id_seq'::regclass);


--
-- Name: ai_triage_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_triage_record ALTER COLUMN id SET DEFAULT nextval('public.ai_triage_record_id_seq'::regclass);


--
-- Name: check_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request ALTER COLUMN id SET DEFAULT nextval('public.check_request_id_seq'::regclass);


--
-- Name: department id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department ALTER COLUMN id SET DEFAULT nextval('public.department_id_seq'::regclass);


--
-- Name: disease id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disease ALTER COLUMN id SET DEFAULT nextval('public.disease_id_seq'::regclass);


--
-- Name: disposal_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request ALTER COLUMN id SET DEFAULT nextval('public.disposal_request_id_seq'::regclass);


--
-- Name: doctor_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule ALTER COLUMN id SET DEFAULT nextval('public.doctor_schedule_id_seq'::regclass);


--
-- Name: drug_info id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drug_info ALTER COLUMN id SET DEFAULT nextval('public.drug_info_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: expense_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expense_record ALTER COLUMN id SET DEFAULT nextval('public.expense_record_id_seq'::regclass);


--
-- Name: inspection_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request ALTER COLUMN id SET DEFAULT nextval('public.inspection_request_id_seq'::regclass);


--
-- Name: leave_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_request ALTER COLUMN id SET DEFAULT nextval('public.leave_request_id_seq'::regclass);


--
-- Name: medical_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record ALTER COLUMN id SET DEFAULT nextval('public.medical_record_id_seq'::regclass);


--
-- Name: medical_technology id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_technology ALTER COLUMN id SET DEFAULT nextval('public.medical_technology_id_seq'::regclass);


--
-- Name: patient id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient ALTER COLUMN id SET DEFAULT nextval('public.patient_id_seq'::regclass);


--
-- Name: patient_balance_transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_balance_transaction ALTER COLUMN id SET DEFAULT nextval('public.patient_balance_transaction_id_seq'::regclass);


--
-- Name: prescription id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prescription ALTER COLUMN id SET DEFAULT nextval('public.prescription_id_seq'::regclass);


--
-- Name: regist_level id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regist_level ALTER COLUMN id SET DEFAULT nextval('public.regist_level_id_seq'::regclass);


--
-- Name: register id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register ALTER COLUMN id SET DEFAULT nextval('public.register_id_seq'::regclass);


--
-- Name: schedule_adjust_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_log ALTER COLUMN id SET DEFAULT nextval('public.schedule_adjust_log_id_seq'::regclass);


--
-- Name: schedule_adjust_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_request ALTER COLUMN id SET DEFAULT nextval('public.schedule_adjust_request_id_seq'::regclass);


--
-- Name: schedule_plan id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_plan ALTER COLUMN id SET DEFAULT nextval('public.schedule_plan_id_seq'::regclass);


--
-- Name: settle_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settle_category ALTER COLUMN id SET DEFAULT nextval('public.settle_category_id_seq'::regclass);


--
-- Name: triage_desk_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triage_desk_record ALTER COLUMN id SET DEFAULT nextval('public.triage_desk_record_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ai_consultation_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_consultation_record (id, register_id, round_number, ai_question, patient_answer, consultation_state, chief_complaint, symptom_duration, history_summary, allergy_summary, medication_summary, ai_summary, suggested_exam, creation_time, completion_time, model_id, patient_id, session_uuid, updated_at) FROM stdin;
6	6	1	您好，请问今天哪里不舒服？最难受的是什么？	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:44:53.342487	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
7	6	2	\N	我这两天心脏有一些针扎的那种疼痛	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:06.373514	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
8	6	3	好的，这种针扎一样的感觉，大概持续多久了？	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:07.563498	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
9	6	4	\N	1-3天	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:10.080838	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
10	6	5	嗯，明白了。除了这个心脏针扎的感觉，还有没有其他不舒服？比如胸闷、心慌或者发烧？	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:11.357837	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
11	6	6	\N	胸闷可能	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:20.595902	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
12	6	7	好的，那您以前有过心脏病、高血压这些情况吗？平时有在长期吃什么药吗？	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:21.897275	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
13	6	8	\N	我没有别的病史，我现在有一些头孢过敏反正	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:39.840273	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
14	6	9	收到，头孢过敏已记下。那您平时有在长期吃什么药吗？比如降压药、降糖药之类的？	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:41.171322	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
15	6	10	\N	没有吃	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:47.761536	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
16	6	11	好的，信息都记下了。就诊时记得跟医生说一下头孢过敏和胸闷的情况。\n<<PRECONSULT_DONE>>	\N	completed	心脏针扎样疼痛伴胸闷2天	1-3天	无高血压、心脏病等慢性病史。	头孢过敏	无长期用药	患者近1-3天出现心脏针扎样疼痛，伴有胸闷，无发热、心慌等其他不适。	["心电图","心肌酶谱","心脏超声"]	2026-06-11 13:45:49.114147	2026-06-11 13:45:51.059243	deepseek-chat	9	aefec4e7-36aa-4bf1-aa26-d8a19b7e8973	2026-06-11 13:45:51.166138
\.


--
-- Data for Name: ai_diagnosis_suggestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_diagnosis_suggestion (id, register_id, disease_id, disease_name, recommend_icd, probability, risk_level, treatment_direction, diagnosis_basis, is_adopted, sort_order, creation_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_exam_analysis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_exam_analysis (id, register_id, check_request_id, inspection_request_id, analysis_type, original_result, abnormal_indicators, risk_level, analysis_report, correlation_analysis, is_viewed, analysis_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_exam_suggestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_exam_suggestion (id, register_id, tech_id, tech_name, suggest_type, suggest_reason, priority, is_adopted, creation_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_follow_up_plan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_follow_up_plan (id, register_id, prescription_id, follow_up_day, planned_date, follow_up_type, content_template, plan_status, creation_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_follow_up_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_follow_up_record (id, follow_up_plan_id, register_id, is_on_time, side_effect, has_side_effect, symptom_relief, need_revisit, patient_feedback, ai_assessment, ai_advice, follow_up_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_medical_record_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_medical_record_log (id, register_id, medical_record_id, source_type, ai_readme, ai_present, ai_history, ai_allergy, ai_physique, ai_diagnosis, is_adopted, doctor_modification, generation_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_prescription_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_prescription_review (id, register_id, prescription_id, review_result, drug_conflict, allergy_risk, duplicate_drug, dosage_check, risk_score, risk_details, doctor_action, review_time, model_id) FROM stdin;
\.


--
-- Data for Name: ai_triage_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_triage_record (id, patient_name, patient_age, patient_gender, symptom_description, recommend_dept_id, recommend_dept_name, recommend_doctor_id, recommend_doctor_name, risk_level, is_priority, ai_analysis, register_id, triage_time, model_id) FROM stdin;
5	匿名患者	\N	\N	我走路腿卡了，现在有点疼怎么办\n	11	骨科	\N	\N	low	0	{"suggestedExaminations":["体格检查","必要时X线检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","肌肉拉伤","关节扭伤"]}	\N	2026-06-03 20:17:30.514226	deepseek-chat
6	匿名患者	\N	\N	胃疼三天，伴有反酸和嗳气	4	消化内科	\N	\N	low	0	{"suggestedExaminations":["胃镜检查","幽门螺杆菌检测","血常规"],"selfCareAdvice":"建议就医","possibleConditions":["慢性胃炎","胃食管反流病","消化性溃疡"]}	\N	2026-06-03 20:25:40.910031	deepseek-chat
7	匿名患者	\N	\N	我摔了一跤，腿有点疼\n	9	骨科	\N	\N	low	0	{"suggestedExaminations":["体格检查","X光检查（必要时）"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","肌肉拉伤","轻微骨折"]}	\N	2026-06-03 20:34:13.598319	deepseek-chat
8	匿名患者	\N	\N	我现在腿很疼怎么办，头两天摔了一觉	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X线检查（排除骨折）","体格检查（评估肿胀和活动度）"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","肌肉拉伤","骨折（若疼痛剧烈或畸形）"]}	\N	2026-06-03 20:37:47.514585	deepseek-chat
9	匿名患者	\N	\N	我现在腿很疼怎么办，头两天摔了一觉	9	骨科	\N	\N	medium	0	{"suggestedExaminations":["X光检查","必要时CT或MRI检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","骨折或骨裂","韧带拉伤"]}	\N	2026-06-03 20:39:02.497101	deepseek-chat
10	匿名患者	\N	\N	我头两天摔了一跤，现在骨头有点疼\n	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X光检查","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","骨裂或骨折"]}	\N	2026-06-03 20:44:41.218658	deepseek-chat
11	匿名患者	\N	\N	我头两天摔了一跤，现在腿有点疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["体格检查","X光片"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","肌肉拉伤","轻微骨折"]}	\N	2026-06-03 20:57:39.517088	deepseek-chat
12	匿名患者	\N	\N	我头两天摔了一跤，现在腿有点疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X光片检查","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","轻度骨折或骨裂"]}	\N	2026-06-03 21:02:39.382185	deepseek-chat
13	匿名患者	\N	\N	我头两天摔了一觉，然后现在腿很疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X线检查","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","韧带拉伤","骨折"]}	\N	2026-06-03 21:07:09.026156	deepseek-chat
14	匿名患者	\N	\N	我摔了一跤，现在腿有点疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X光检查","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","肌肉拉伤","轻微骨折"]}	\N	2026-06-03 21:09:43.064577	deepseek-chat
15	匿名患者	\N	\N	我现在腿有点疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["体格检查","X光检查","血常规"],"selfCareAdvice":"建议就医","possibleConditions":["肌肉劳损","关节炎","下肢静脉曲张"]}	\N	2026-06-03 21:12:40.381799	deepseek-chat
16	匿名患者	\N	\N	头两天摔了一跤，然后今天骨头疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X线检查（排除骨折）","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","骨裂或骨折（轻微）","关节扭伤"]}	\N	2026-06-05 18:13:05.722129	deepseek-chat
17	匿名患者	\N	\N	发热咳嗽、胃肠不适、头晕乏力	2	呼吸内科	\N	\N	medium	0	{"suggestedExaminations":["血常规","C反应蛋白","胸部X光检查"],"selfCareAdvice":"建议就医","possibleConditions":["上呼吸道感染","流行性感冒","急性支气管炎"]}	\N	2026-06-09 15:45:23.273611	deepseek-chat
18	匿名患者	\N	\N	我现在想挂内科，有点急\n	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-09 15:48:36.011639	deepseek-chat
19	匿名患者	\N	\N	我现在想报内科	1	内科	\N	\N	low	0	{"suggestedExaminations":["建议根据具体症状进一步检查"],"selfCareAdvice":"建议就医","possibleConditions":["待明确"]}	\N	2026-06-09 17:48:14.774713	deepseek-chat
20	匿名患者	\N	\N	我想挂内科	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-09 19:17:28.848305	deepseek-chat
21	匿名患者	\N	\N	我想挂内科\n	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-09 19:32:18.770755	deepseek-chat
22	匿名患者	\N	\N	我想挂内科	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-09 19:34:37.339319	deepseek-chat
23	匿名患者	\N	\N	我现在想挂内科	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-09 19:51:44.179894	deepseek-chat
24	匿名患者	\N	\N	我这两天心脏有点疼	3	心血管内科	\N	\N	medium	0	{"suggestedExaminations":["心电图","心肌酶谱","心脏超声"],"selfCareAdvice":"建议就医","possibleConditions":["心绞痛","心肌炎","肋间神经痛"]}	\N	2026-06-10 19:21:33.771447	deepseek-chat
25	匿名患者	\N	\N	我这两天心脏有一些难受。	3	心血管内科	\N	\N	medium	0	{"suggestedExaminations":["心电图","心肌酶谱检查","心脏彩超"],"selfCareAdvice":"建议就医","possibleConditions":["心律失常","冠心病","心肌炎"]}	\N	2026-06-10 19:23:03.876499	deepseek-chat
26	匿名患者	\N	\N	哦。	1	内科	\N	\N	low	0	{"suggestedExaminations":[],"selfCareAdvice":"建议就医","possibleConditions":[]}	\N	2026-06-10 19:26:35.561477	deepseek-chat
27	匿名患者	\N	\N	我这两天心脏有一些疼。	3	心血管内科	\N	\N	medium	0	{"suggestedExaminations":["心电图","心肌酶谱","心脏超声"],"selfCareAdvice":"建议就医","possibleConditions":["心绞痛","心肌缺血","心脏神经官能症","肋间神经痛"]}	\N	2026-06-10 19:26:54.542416	deepseek-chat
28	匿名患者	\N	\N	我感觉心脏疼，有时候总想针扎的跳跳的疼	3	心血管内科	\N	\N	low	0	{"suggestedExaminations":["心电图","心肌酶谱","心脏超声"],"selfCareAdvice":"建议就医","possibleConditions":["肋间神经痛","心脏神经官能症","心肌炎"]}	\N	2026-06-11 10:13:51.371186	deepseek-chat
29	匿名患者	\N	\N	ͷʹ	5	神经内科	\N	\N	low	0	{"suggestedExaminations":["血常规检查","血压测量"],"selfCareAdvice":"建议就医","possibleConditions":["紧张性头痛","偏头痛","颈椎病相关头痛"]}	\N	2026-06-11 11:21:27.449013	deepseek-chat
30	匿名患者	\N	\N	我这两天摔了一跤，骨头很不舒服	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X线检查","体格检查"],"selfCareAdvice":"建议就医","possibleConditions":["软组织挫伤","骨折","关节损伤"]}	\N	2026-06-15 18:28:26.419229	deepseek-chat
31	匿名患者	\N	\N	我头两天摔了一跤，骨头疼	9	骨科	\N	\N	low	0	{"suggestedExaminations":["X线检查","必要时CT检查"],"selfCareAdvice":"建议就医","possibleConditions":["骨挫伤","轻微骨折","软组织损伤"]}	\N	2026-06-15 18:29:48.613616	deepseek-chat
\.


--
-- Data for Name: check_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.check_request (id, register_id, medical_technology_id, check_info, check_position, creation_time, check_employee_id, inputcheck_employee_id, check_time, check_result, check_state, check_remark) FROM stdin;
\.


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (id, dept_code, dept_name, dept_type, delmark, dept_description) FROM stdin;
2	HXNK	呼吸内科	临床科室	0	关注咳嗽、气喘、肺炎、慢阻肺、支气管炎等呼吸系统疾病。
3	XXNK	心血管内科	临床科室	0	处理胸闷胸痛、心悸、高血压、冠心病、心律失常等问题。
4	XHNK	消化内科	临床科室	0	面向胃痛腹胀、反酸、腹泻、肝胆胰及消化道相关疾病。
5	SJNK	神经内科	临床科室	0	关注头痛头晕、失眠、肢体麻木、脑血管和神经系统疾病。
6	SNK	肾内科	临床科室	0	处理水肿、尿检异常、肾炎、肾功能异常及慢性肾病管理。
7	NFMK	内分泌科	临床科室	0	面向糖尿病、甲状腺疾病、代谢异常、肥胖和骨质疏松等问题。
8	WK	外科	临床科室	0	处理体表包块、外伤、腹部外科疾病及需要手术评估的问题。
9	GC	骨科	临床科室	0	关注关节疼痛、骨折损伤、颈肩腰腿痛、运动损伤等骨骼肌肉问题。
10	FCHK	妇产科	临床科室	0	提供妇科疾病、孕产期咨询、月经异常和女性健康管理服务。
11	EK	儿科	临床科室	0	面向儿童发热、咳嗽、腹泻、过敏、生长发育等常见问题。
12	XSEK	新生儿科	临床科室	0	关注新生儿喂养、黄疸、早产儿随访和出生后健康评估。
13	YFK	眼科	临床科室	0	处理视力下降、眼红眼痛、干眼、白内障、青光眼等眼部问题。
14	EBHK	耳鼻咽喉科	临床科室	0	面向鼻炎、咽喉不适、耳鸣听力下降、扁桃体和鼻窦问题。
15	KQK	口腔科	临床科室	0	提供牙痛、龋齿、牙周问题、口腔黏膜和口腔保健服务。
16	PFK	皮肤科	临床科室	0	处理皮疹、瘙痒、痤疮、湿疹、过敏和感染性皮肤问题。
17	ZYK	中医科	临床科室	0	结合中医辨证，提供慢病调理、体质调养和康复辅助服务。
18	ZLK	肿瘤科	临床科室	0	面向肿瘤筛查咨询、治疗评估、复查随访和症状管理。
19	JZK	急诊科	临床科室	0	处理突发不适、急性疼痛、外伤和需要快速评估的急症情况。
20	KFY	康复医学科	临床科室	0	提供术后、卒中、骨伤和慢病后的功能恢复与康复指导。
1	NK	内科	临床科室	0	常见内科疾病、慢病复诊、发热乏力等综合性问题的首选科室。
35	FSK	放射科	医技科室	0	\N
36	CSK	超声科	医技科室	0	\N
37	JYK	检验科	医技科室	0	\N
38	YXK	输血科	医技科室	0	\N
39	BLK	病理科	医技科室	0	\N
40	CZK	处置室	医技科室	0	\N
41	NJZX	内镜中心	医技科室	0	\N
42	SS	手术室	医技科室	0	\N
44	XDZX	消毒供应中心	医技科室	0	\N
45	YF	药房	医技科室	0	\N
\.


--
-- Data for Name: disease; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.disease (id, disease_code, disease_name, diseaseicd, disease_category) FROM stdin;
1	PJT	偏头痛	G43.9	神经系统疾病
2	SXDGR	上呼吸道感染	J06.9	呼吸系统疾病
3	FY	肺炎	J18.9	呼吸系统疾病
\.


--
-- Data for Name: disposal_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.disposal_request (id, register_id, medical_technology_id, disposal_info, disposal_position, creation_time, disposal_employee_id, inputdisposal_employee_id, disposal_time, disposal_result, disposal_state, disposal_remark) FROM stdin;
\.


--
-- Data for Name: doctor_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_schedule (id, plan_id, physician_id, department_id, work_date, time_slot, regist_level_id, total_quota, used_quota, available_quota, price, status, ai_suggestion, modified, modify_remark, created_time, update_time, delmark) FROM stdin;
1	3	5	1	2026-07-01	上午	3	30	0	30	30.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
2	3	4	1	2026-07-01	上午	2	25	0	25	20.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
3	3	1	1	2026-07-01	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
4	3	2	1	2026-07-01	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
5	3	3	1	2026-07-02	上午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
6	3	5	1	2026-07-02	上午	3	30	0	30	30.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
7	3	4	1	2026-07-02	下午	2	25	0	25	20.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
8	3	1	1	2026-07-02	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
9	3	2	1	2026-07-03	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
10	3	3	1	2026-07-03	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
11	3	5	1	2026-07-03	下午	3	30	0	30	30.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
12	3	4	1	2026-07-03	下午	2	25	0	25	20.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
13	3	4	1	2026-07-04	上午	2	25	0	25	20.00	正常	节假日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
14	3	3	1	2026-07-05	上午	1	50	0	50	15.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
15	3	5	1	2026-07-05	下午	3	30	0	30	30.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
16	3	1	1	2026-07-06	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
17	3	2	1	2026-07-06	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
18	3	4	1	2026-07-06	下午	2	25	0	25	20.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
19	3	5	1	2026-07-06	下午	3	30	0	30	30.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
20	3	3	1	2026-07-07	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
21	3	1	1	2026-07-07	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
22	3	2	1	2026-07-07	下午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
23	3	4	1	2026-07-07	下午	2	25	0	25	20.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
24	3	5	1	2026-07-08	上午	3	30	0	30	30.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
25	3	3	1	2026-07-08	上午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
26	3	1	1	2026-07-08	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
27	3	2	1	2026-07-08	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
28	3	4	1	2026-07-09	上午	2	25	0	25	20.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
29	3	5	1	2026-07-09	上午	3	30	0	30	30.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
30	3	3	1	2026-07-09	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
31	3	1	1	2026-07-09	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
32	3	2	1	2026-07-10	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
33	3	3	1	2026-07-10	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
34	3	4	1	2026-07-10	下午	2	25	0	25	20.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
35	3	5	1	2026-07-10	下午	3	30	0	30	30.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
36	3	5	1	2026-07-11	上午	3	30	0	30	30.00	正常	周六半天出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
37	3	4	1	2026-07-12	上午	2	25	0	25	20.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
38	3	1	1	2026-07-12	下午	1	50	0	50	15.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
39	3	2	1	2026-07-13	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
40	3	3	1	2026-07-13	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
41	3	4	1	2026-07-13	下午	2	25	0	25	20.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
42	3	5	1	2026-07-13	下午	3	30	0	30	30.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
43	3	1	1	2026-07-14	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
44	3	2	1	2026-07-14	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
45	3	3	1	2026-07-14	下午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
46	3	4	1	2026-07-14	下午	2	25	0	25	20.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
47	3	5	1	2026-07-15	上午	3	30	0	30	30.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
48	3	1	1	2026-07-15	上午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
49	3	2	1	2026-07-15	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
50	3	3	1	2026-07-15	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
51	3	4	1	2026-07-16	上午	2	25	0	25	20.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
52	3	5	1	2026-07-16	上午	3	30	0	30	30.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
53	3	1	1	2026-07-16	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
54	3	2	1	2026-07-16	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
55	3	3	1	2026-07-17	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
56	3	1	1	2026-07-17	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
57	3	4	1	2026-07-17	下午	2	25	0	25	20.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
58	3	5	1	2026-07-17	下午	3	30	0	30	30.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
59	3	3	1	2026-07-18	上午	1	50	0	50	15.00	正常	周六半天出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
60	3	2	1	2026-07-19	上午	1	50	0	50	15.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
61	3	4	1	2026-07-19	下午	2	25	0	25	20.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
62	3	1	1	2026-07-20	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
63	3	2	1	2026-07-20	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
64	3	4	1	2026-07-20	下午	2	25	0	25	20.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
65	3	5	1	2026-07-20	下午	3	30	0	30	30.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
66	3	3	1	2026-07-21	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
67	3	1	1	2026-07-21	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
68	3	2	1	2026-07-21	下午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
69	3	4	1	2026-07-21	下午	2	25	0	25	20.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
70	3	5	1	2026-07-22	上午	3	30	0	30	30.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
71	3	3	1	2026-07-22	上午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
72	3	1	1	2026-07-22	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
73	3	2	1	2026-07-22	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
74	3	4	1	2026-07-23	上午	2	25	0	25	20.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
75	3	5	1	2026-07-23	上午	3	30	0	30	30.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
76	3	3	1	2026-07-23	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
77	3	1	1	2026-07-23	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
78	3	2	1	2026-07-24	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
79	3	3	1	2026-07-24	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
80	3	4	1	2026-07-24	下午	2	25	0	25	20.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
81	3	5	1	2026-07-24	下午	3	30	0	30	30.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
82	3	1	1	2026-07-25	上午	1	50	0	50	15.00	正常	周六半天出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
83	3	5	1	2026-07-26	上午	3	30	0	30	30.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
84	3	3	1	2026-07-26	下午	1	50	0	50	15.00	正常	周日出诊安排	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
85	3	1	1	2026-07-27	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
86	3	2	1	2026-07-27	上午	1	50	0	50	15.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
87	3	4	1	2026-07-27	下午	2	25	0	25	20.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
88	3	5	1	2026-07-27	下午	3	30	0	30	30.00	正常	匹配周一号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
89	3	3	1	2026-07-28	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
90	3	1	1	2026-07-28	上午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
91	3	2	1	2026-07-28	下午	1	50	0	50	15.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
92	3	4	1	2026-07-28	下午	2	25	0	25	20.00	正常	匹配周二号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
93	3	5	1	2026-07-29	上午	3	30	0	30	30.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
94	3	3	1	2026-07-29	上午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
95	3	1	1	2026-07-29	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
96	3	2	1	2026-07-29	下午	1	50	0	50	15.00	正常	匹配周三号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
97	3	4	1	2026-07-30	上午	2	25	0	25	20.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
98	3	5	1	2026-07-30	上午	3	30	0	30	30.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
99	3	3	1	2026-07-30	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
100	3	1	1	2026-07-30	下午	1	50	0	50	15.00	正常	匹配周四号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
101	3	2	1	2026-07-31	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
102	3	3	1	2026-07-31	上午	1	50	0	50	15.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
103	3	4	1	2026-07-31	下午	2	25	0	25	20.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
104	3	5	1	2026-07-31	下午	3	30	0	30	30.00	正常	匹配周五号源需求	f	\N	2026-06-09 10:35:15.677022	2026-06-09 10:35:15.677022	0
105	4	5	1	2026-06-01	上午	3	30	0	30	30.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
106	4	1	1	2026-06-01	上午	1	50	0	50	15.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
107	4	4	1	2026-06-01	下午	2	25	0	25	20.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
108	4	2	1	2026-06-01	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
109	4	4	1	2026-06-02	上午	2	25	0	25	20.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
110	4	3	1	2026-06-02	上午	1	50	0	50	15.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
111	4	5	1	2026-06-02	下午	3	30	0	30	30.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
112	4	1	1	2026-06-02	下午	1	50	0	50	15.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
113	4	1	1	2026-06-03	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
114	4	2	1	2026-06-03	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
115	4	3	1	2026-06-03	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
116	4	2	1	2026-06-03	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
117	4	2	1	2026-06-04	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
118	4	3	1	2026-06-04	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
119	4	5	1	2026-06-04	下午	3	30	0	30	30.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
120	4	1	1	2026-06-04	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
121	4	5	1	2026-06-05	上午	3	30	0	30	30.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
122	4	4	1	2026-06-05	上午	2	25	0	25	20.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
123	4	1	1	2026-06-05	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
124	4	2	1	2026-06-05	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
125	4	3	1	2026-06-06	上午	1	50	0	50	15.00	正常	周六仅安排上午出诊	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
126	4	5	1	2026-06-07	上午	3	30	0	30	30.00	正常	法定假日，按需配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
127	4	3	1	2026-06-07	下午	1	50	0	50	15.00	正常	法定假日，少量配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
128	4	4	1	2026-06-08	上午	2	25	0	25	20.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
129	4	1	1	2026-06-08	上午	1	50	0	50	15.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
130	4	2	1	2026-06-08	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
131	4	3	1	2026-06-08	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
132	4	5	1	2026-06-09	上午	3	30	0	30	30.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
133	4	2	1	2026-06-09	上午	1	50	0	50	15.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
134	4	4	1	2026-06-09	下午	2	25	0	25	20.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
136	4	1	1	2026-06-10	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
137	4	3	1	2026-06-10	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
138	4	2	1	2026-06-10	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
139	4	1	1	2026-06-10	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
141	4	1	1	2026-06-11	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
142	4	2	1	2026-06-11	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
143	4	3	1	2026-06-11	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
144	4	5	1	2026-06-12	上午	3	30	0	30	30.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
145	4	3	1	2026-06-12	上午	1	50	0	50	15.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
146	4	1	1	2026-06-12	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
147	4	2	1	2026-06-12	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
148	4	2	1	2026-06-13	上午	1	50	0	50	15.00	正常	周六仅安排上午出诊	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
149	4	4	1	2026-06-14	上午	2	25	0	25	20.00	正常	法定假日，按需配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
150	4	1	1	2026-06-14	下午	1	50	0	50	15.00	正常	法定假日，少量配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
151	4	5	1	2026-06-15	上午	3	30	0	30	30.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
152	4	2	1	2026-06-15	上午	1	50	0	50	15.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
153	4	4	1	2026-06-15	下午	2	25	0	25	20.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
154	4	3	1	2026-06-15	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
155	4	4	1	2026-06-16	上午	2	25	0	25	20.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
156	4	1	1	2026-06-16	上午	1	50	0	50	15.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
157	4	5	1	2026-06-16	下午	3	30	0	30	30.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
158	4	2	1	2026-06-16	下午	1	50	0	50	15.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
159	4	1	1	2026-06-17	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
160	4	2	1	2026-06-17	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
161	4	3	1	2026-06-17	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
162	4	1	1	2026-06-17	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
163	4	2	1	2026-06-18	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
164	4	3	1	2026-06-18	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
140	4	4	1	2026-06-11	上午	2	25	1	24	20.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-10 20:04:46.908296	0
165	4	5	1	2026-06-18	下午	3	30	0	30	30.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
166	4	1	1	2026-06-18	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
167	4	5	1	2026-06-19	上午	3	30	0	30	30.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
168	4	4	1	2026-06-19	上午	2	25	0	25	20.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
169	4	1	1	2026-06-19	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
170	4	3	1	2026-06-19	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
171	4	2	1	2026-06-20	上午	1	50	0	50	15.00	正常	周六仅安排上午出诊	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
172	4	5	1	2026-06-21	上午	3	30	0	30	30.00	正常	法定假日，按需配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
173	4	3	1	2026-06-21	下午	1	50	0	50	15.00	正常	法定假日，少量配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
174	4	4	1	2026-06-22	上午	2	25	0	25	20.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
175	4	1	1	2026-06-22	上午	1	50	0	50	15.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
176	4	2	1	2026-06-22	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
177	4	3	1	2026-06-22	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
178	4	5	1	2026-06-23	上午	3	30	0	30	30.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
179	4	2	1	2026-06-23	上午	1	50	0	50	15.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
180	4	4	1	2026-06-23	下午	2	25	0	25	20.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
181	4	1	1	2026-06-23	下午	1	50	0	50	15.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
182	4	1	1	2026-06-24	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
183	4	2	1	2026-06-24	上午	1	50	0	50	15.00	正常	周三需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
184	4	3	1	2026-06-24	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
185	4	2	1	2026-06-24	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
186	4	4	1	2026-06-25	上午	2	25	0	25	20.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
187	4	3	1	2026-06-25	上午	1	50	0	50	15.00	正常	周四需求低，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
188	4	1	1	2026-06-25	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
189	4	2	1	2026-06-25	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
190	4	5	1	2026-06-26	上午	3	30	0	30	30.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
191	4	4	1	2026-06-26	上午	2	25	0	25	20.00	正常	周五需求中等，合理配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
192	4	1	1	2026-06-26	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
193	4	3	1	2026-06-26	下午	1	50	0	50	15.00	正常	中等需求，常规配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
194	4	1	1	2026-06-27	上午	1	50	0	50	15.00	正常	周六仅安排上午出诊	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
195	4	4	1	2026-06-28	上午	2	25	0	25	20.00	正常	法定假日，按需配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
196	4	2	1	2026-06-28	下午	1	50	0	50	15.00	正常	法定假日，少量配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
197	4	5	1	2026-06-29	上午	3	30	0	30	30.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
198	4	2	1	2026-06-29	上午	1	50	0	50	15.00	正常	周一需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
199	4	3	1	2026-06-29	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
200	4	1	1	2026-06-29	下午	1	50	0	50	15.00	正常	常规配置，满足需求	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
201	4	4	1	2026-06-30	上午	2	25	0	25	20.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
202	4	1	1	2026-06-30	上午	1	50	0	50	15.00	正常	周二需求高，充足号源	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
203	4	5	1	2026-06-30	下午	3	30	0	30	30.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
204	4	2	1	2026-06-30	下午	1	50	0	50	15.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-09 13:55:17.017958	0
205	5	45	9	2026-06-01	上午	3	30	0	30	30.00	正常	周一需求高，安排主任出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
206	5	41	9	2026-06-01	上午	1	50	0	50	15.00	正常	号源充足，匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
207	5	42	9	2026-06-01	下午	1	50	0	50	15.00	正常	排班合规，号源合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
208	5	43	9	2026-06-01	下午	1	50	0	50	15.00	正常	满足日常就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
209	5	44	9	2026-06-02	上午	2	25	0	25	20.00	正常	周二需求高，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
210	5	41	9	2026-06-02	上午	1	50	0	50	15.00	正常	号源匹配就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
211	5	42	9	2026-06-02	下午	1	50	0	50	15.00	正常	排班符合规则要求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
212	5	43	9	2026-06-02	下午	1	50	0	50	15.00	正常	保障日常接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
213	5	45	9	2026-06-03	上午	3	30	0	30	30.00	正常	周三需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
214	5	42	9	2026-06-03	上午	1	50	0	50	15.00	正常	号源配置合理合规	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
215	5	41	9	2026-06-03	下午	1	50	0	50	15.00	正常	满足普通就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
216	5	43	9	2026-06-03	下午	1	50	0	50	15.00	正常	排班符合规则要求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
217	5	44	9	2026-06-04	上午	2	25	0	25	20.00	正常	周四需求低，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
218	5	41	9	2026-06-04	上午	1	50	0	50	15.00	正常	号源匹配需求水平	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
219	5	42	9	2026-06-04	下午	1	50	0	50	15.00	正常	保障日常接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
220	5	43	9	2026-06-04	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
221	5	45	9	2026-06-05	上午	3	30	0	30	30.00	正常	周五需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
222	5	41	9	2026-06-05	上午	1	50	0	50	15.00	正常	号源配置符合规律	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
223	5	42	9	2026-06-05	下午	1	50	0	50	15.00	正常	满足周末前就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
224	5	43	9	2026-06-05	下午	1	50	0	50	15.00	正常	排班符合规则要求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
225	5	44	9	2026-06-06	上午	2	25	0	25	20.00	正常	周六仅上午出诊，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
226	5	41	9	2026-06-07	上午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
227	5	42	9	2026-06-07	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
228	5	45	9	2026-06-08	上午	3	30	0	30	30.00	正常	周一需求高，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
229	5	43	9	2026-06-08	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
230	5	41	9	2026-06-08	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
231	5	42	9	2026-06-08	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
232	5	44	9	2026-06-09	上午	2	25	0	25	20.00	正常	周二需求高，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
233	5	41	9	2026-06-09	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
234	5	42	9	2026-06-09	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
235	5	43	9	2026-06-09	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
236	5	45	9	2026-06-10	上午	3	30	0	30	30.00	正常	周三需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
237	5	42	9	2026-06-10	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
238	5	41	9	2026-06-10	下午	1	50	0	50	15.00	正常	保障日常接诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
239	5	43	9	2026-06-10	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
240	5	44	9	2026-06-11	上午	2	25	0	25	20.00	正常	周四需求低，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
241	5	41	9	2026-06-11	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
242	5	42	9	2026-06-11	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
243	5	43	9	2026-06-11	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
244	5	45	9	2026-06-12	上午	3	30	0	30	30.00	正常	周五需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
245	5	41	9	2026-06-12	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
246	5	42	9	2026-06-12	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
247	5	43	9	2026-06-12	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
248	5	42	9	2026-06-13	上午	1	50	0	50	15.00	正常	周六仅上午出诊，安排普通号	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
249	5	44	9	2026-06-14	上午	2	25	0	25	20.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
250	5	43	9	2026-06-14	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
251	5	45	9	2026-06-15	上午	3	30	0	30	30.00	正常	周一需求高，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
252	5	41	9	2026-06-15	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
253	5	42	9	2026-06-15	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
254	5	43	9	2026-06-15	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
255	5	44	9	2026-06-16	上午	2	25	0	25	20.00	正常	周二需求高，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
256	5	41	9	2026-06-16	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
258	5	43	9	2026-06-16	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
259	5	45	9	2026-06-17	上午	3	30	0	30	30.00	正常	周三需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
260	5	42	9	2026-06-17	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
261	5	41	9	2026-06-17	下午	1	50	0	50	15.00	正常	保障日常接诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
262	5	43	9	2026-06-17	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
263	5	44	9	2026-06-18	上午	2	25	0	25	20.00	正常	周四需求低，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
264	5	41	9	2026-06-18	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
265	5	42	9	2026-06-18	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
266	5	43	9	2026-06-18	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
267	5	45	9	2026-06-19	上午	3	30	0	30	30.00	正常	周五需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
268	5	41	9	2026-06-19	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
269	5	42	9	2026-06-19	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
270	5	43	9	2026-06-19	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
271	5	43	9	2026-06-20	上午	1	50	0	50	15.00	正常	周六仅上午出诊，安排普通号	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
272	5	41	9	2026-06-21	上午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
273	5	42	9	2026-06-21	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
274	5	45	9	2026-06-22	上午	3	30	0	30	30.00	正常	周一需求高，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
275	5	41	9	2026-06-22	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
276	5	42	9	2026-06-22	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
277	5	43	9	2026-06-22	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
278	5	44	9	2026-06-23	上午	2	25	0	25	20.00	正常	周二需求高，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
279	5	41	9	2026-06-23	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
280	5	42	9	2026-06-23	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
281	5	43	9	2026-06-23	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
282	5	45	9	2026-06-24	上午	3	30	0	30	30.00	正常	周三需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
283	5	42	9	2026-06-24	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
284	5	41	9	2026-06-24	下午	1	50	0	50	15.00	正常	保障日常接诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
285	5	43	9	2026-06-24	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
286	5	44	9	2026-06-25	上午	2	25	0	25	20.00	正常	周四需求低，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
287	5	41	9	2026-06-25	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
288	5	42	9	2026-06-25	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
289	5	43	9	2026-06-25	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
290	5	45	9	2026-06-26	上午	3	30	0	30	30.00	正常	周五需求中等，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
291	5	41	9	2026-06-26	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
292	5	42	9	2026-06-26	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
293	5	43	9	2026-06-26	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
294	5	41	9	2026-06-27	上午	1	50	0	50	15.00	正常	周六仅上午出诊，安排普通号	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
295	5	44	9	2026-06-28	上午	2	25	0	25	20.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
296	5	43	9	2026-06-28	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
297	5	45	9	2026-06-29	上午	3	30	0	30	30.00	正常	周一需求高，安排主任	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
298	5	41	9	2026-06-29	上午	1	50	0	50	15.00	正常	号源匹配需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
299	5	42	9	2026-06-29	下午	1	50	0	50	15.00	正常	排班合规合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
300	5	43	9	2026-06-29	下午	1	50	0	50	15.00	正常	保障接诊能力	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
301	5	44	9	2026-06-30	上午	2	25	0	25	20.00	正常	周二需求高，安排专家	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
302	5	41	9	2026-06-30	上午	1	50	0	50	15.00	正常	号源配置合理	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
303	5	42	9	2026-06-30	下午	1	50	0	50	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
304	5	43	9	2026-06-30	下午	1	50	0	50	15.00	正常	排班符合规则	f	\N	2026-06-09 15:48:50.985394	2026-06-09 15:48:50.985394	0
135	4	3	1	2026-06-09	下午	1	50	0	50	15.00	正常	需求较高，足额配置	f	\N	2026-06-09 13:55:17.017958	2026-06-10 18:07:28.533072	0
305	6	15	3	2026-06-01	上午	3	30	0	30	30.00	正常	周一需求高，安排主任出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
306	6	11	3	2026-06-01	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
307	6	14	3	2026-06-01	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
308	6	12	3	2026-06-01	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
309	6	14	3	2026-06-02	上午	2	25	0	25	20.00	正常	周二需求高，安排专家出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
310	6	13	3	2026-06-02	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
311	6	15	3	2026-06-02	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
312	6	11	3	2026-06-02	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
313	6	15	3	2026-06-03	上午	3	30	0	30	30.00	正常	周三需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
314	6	12	3	2026-06-03	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
315	6	14	3	2026-06-03	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
316	6	13	3	2026-06-03	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
317	6	14	3	2026-06-04	上午	2	25	0	25	20.00	正常	周四需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
318	6	11	3	2026-06-04	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
319	6	15	3	2026-06-04	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
320	6	12	3	2026-06-04	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
321	6	15	3	2026-06-05	上午	3	30	0	30	30.00	正常	周五需求中等，合理安排	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
322	6	13	3	2026-06-05	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
323	6	14	3	2026-06-05	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
324	6	11	3	2026-06-05	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
325	6	11	3	2026-06-06	上午	1	50	0	50	15.00	正常	周六仅上午出诊，满足要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
326	6	15	3	2026-06-07	上午	3	30	0	30	30.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
327	6	14	3	2026-06-07	下午	2	25	0	25	20.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
328	6	14	3	2026-06-08	上午	2	25	0	25	20.00	正常	周一需求高，安排专家出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
329	6	12	3	2026-06-08	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
330	6	15	3	2026-06-08	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
331	6	13	3	2026-06-08	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
332	6	15	3	2026-06-09	上午	3	30	0	30	30.00	正常	周二需求高，安排主任出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
333	6	11	3	2026-06-09	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
334	6	14	3	2026-06-09	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
335	6	12	3	2026-06-09	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
336	6	14	3	2026-06-10	上午	2	25	0	25	20.00	正常	周三需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
337	6	13	3	2026-06-10	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
338	6	15	3	2026-06-10	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
339	6	11	3	2026-06-10	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
341	6	12	3	2026-06-11	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
343	6	13	3	2026-06-11	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
344	6	14	3	2026-06-12	上午	2	25	0	25	20.00	正常	周五需求中等，合理安排	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
345	6	11	3	2026-06-12	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
346	6	15	3	2026-06-12	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
347	6	12	3	2026-06-12	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
348	6	12	3	2026-06-13	上午	1	50	0	50	15.00	正常	周六仅上午出诊，满足要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
349	6	11	3	2026-06-14	上午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
350	6	12	3	2026-06-14	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
351	6	15	3	2026-06-15	上午	3	30	0	30	30.00	正常	周一需求高，安排主任出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
352	6	13	3	2026-06-15	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
353	6	14	3	2026-06-15	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
354	6	11	3	2026-06-15	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
355	6	14	3	2026-06-16	上午	2	25	0	25	20.00	正常	周二需求高，安排专家出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
356	6	12	3	2026-06-16	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
357	6	15	3	2026-06-16	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
358	6	13	3	2026-06-16	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
359	6	15	3	2026-06-17	上午	3	30	0	30	30.00	正常	周三需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
360	6	11	3	2026-06-17	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
361	6	14	3	2026-06-17	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
362	6	12	3	2026-06-17	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
363	6	14	3	2026-06-18	上午	2	25	0	25	20.00	正常	周四需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
364	6	13	3	2026-06-18	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
365	6	15	3	2026-06-18	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
366	6	11	3	2026-06-18	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
367	6	15	3	2026-06-19	上午	3	30	0	30	30.00	正常	周五需求中等，合理安排	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
368	6	12	3	2026-06-19	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
369	6	14	3	2026-06-19	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
370	6	13	3	2026-06-19	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
371	6	13	3	2026-06-20	上午	1	50	0	50	15.00	正常	周六仅上午出诊，满足要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
372	6	14	3	2026-06-21	上午	2	25	0	25	20.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
373	6	13	3	2026-06-21	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
374	6	14	3	2026-06-22	上午	2	25	0	25	20.00	正常	周一需求高，安排专家出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
375	6	11	3	2026-06-22	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
376	6	15	3	2026-06-22	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
377	6	12	3	2026-06-22	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
378	6	15	3	2026-06-23	上午	3	30	0	30	30.00	正常	周二需求高，安排主任出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
379	6	13	3	2026-06-23	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
380	6	14	3	2026-06-23	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
381	6	11	3	2026-06-23	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
340	6	15	3	2026-06-11	上午	3	30	1	29	30.00	正常	周四需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-11 10:14:16.148571	0
382	6	14	3	2026-06-24	上午	2	25	0	25	20.00	正常	周三需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
383	6	12	3	2026-06-24	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
384	6	15	3	2026-06-24	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
385	6	13	3	2026-06-24	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
386	6	15	3	2026-06-25	上午	3	30	0	30	30.00	正常	周四需求低，合理安排出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
387	6	11	3	2026-06-25	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
388	6	14	3	2026-06-25	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
389	6	12	3	2026-06-25	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
390	6	14	3	2026-06-26	上午	2	25	0	25	20.00	正常	周五需求中等，合理安排	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
391	6	13	3	2026-06-26	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
392	6	15	3	2026-06-26	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
393	6	11	3	2026-06-26	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
394	6	11	3	2026-06-27	上午	1	50	0	50	15.00	正常	周六仅上午出诊，满足要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
395	6	12	3	2026-06-28	上午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
396	6	13	3	2026-06-28	下午	1	50	0	50	15.00	正常	法定假日，安排1人出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
397	6	15	3	2026-06-29	上午	3	30	0	30	30.00	正常	周一需求高，安排主任出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
398	6	12	3	2026-06-29	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
399	6	14	3	2026-06-29	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
400	6	13	3	2026-06-29	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
401	6	14	3	2026-06-30	上午	2	25	0	25	20.00	正常	周二需求高，安排专家出诊	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
402	6	11	3	2026-06-30	上午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
403	6	15	3	2026-06-30	下午	3	30	0	30	30.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
404	6	12	3	2026-06-30	下午	1	50	0	50	15.00	正常	满足时段出诊人数要求	f	\N	2026-06-10 18:21:58.591426	2026-06-10 18:21:58.591426	0
342	6	14	3	2026-06-11	下午	2	25	0	25	20.00	正常	需求匹配，排班合理	f	\N	2026-06-10 18:21:58.591426	2026-06-10 19:28:22.474093	0
405	7	25	5	2026-06-01	上午	3	30	0	30	30.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
406	7	24	5	2026-06-01	上午	2	25	0	25	20.00	正常	周一需求高，号源合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
407	7	21	5	2026-06-01	下午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
408	7	22	5	2026-06-01	下午	1	50	0	50	15.00	正常	周一需求高，号源合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
409	7	23	5	2026-06-02	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
410	7	25	5	2026-06-02	上午	3	30	0	30	30.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
411	7	24	5	2026-06-02	下午	2	25	0	25	20.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
412	7	21	5	2026-06-02	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
413	7	22	5	2026-06-03	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
414	7	23	5	2026-06-03	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
415	7	25	5	2026-06-03	下午	3	30	0	30	30.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
416	7	24	5	2026-06-03	下午	2	25	0	25	20.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
417	7	21	5	2026-06-04	上午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
418	7	22	5	2026-06-04	上午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
419	7	23	5	2026-06-04	下午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
420	7	25	5	2026-06-04	下午	3	30	0	30	30.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
421	7	24	5	2026-06-05	上午	2	25	0	25	20.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
422	7	21	5	2026-06-05	上午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
423	7	22	5	2026-06-05	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
424	7	23	5	2026-06-05	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
425	7	25	5	2026-06-06	上午	3	30	0	30	30.00	正常	周六仅上午出诊，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
426	7	24	5	2026-06-07	上午	2	25	0	25	20.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
427	7	21	5	2026-06-07	下午	1	50	0	50	15.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
428	7	22	5	2026-06-08	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
429	7	23	5	2026-06-08	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
430	7	25	5	2026-06-08	下午	3	30	0	30	30.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
431	7	24	5	2026-06-08	下午	2	25	0	25	20.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
432	7	21	5	2026-06-09	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
433	7	22	5	2026-06-09	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
434	7	23	5	2026-06-09	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
435	7	25	5	2026-06-09	下午	3	30	0	30	30.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
436	7	24	5	2026-06-10	上午	2	25	0	25	20.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
437	7	21	5	2026-06-10	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
438	7	22	5	2026-06-10	下午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
439	7	23	5	2026-06-10	下午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
440	7	25	5	2026-06-11	上午	3	30	0	30	30.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
441	7	24	5	2026-06-11	上午	2	25	0	25	20.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
442	7	21	5	2026-06-11	下午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
443	7	22	5	2026-06-11	下午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
444	7	23	5	2026-06-12	上午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
445	7	25	5	2026-06-12	上午	3	30	0	30	30.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
446	7	24	5	2026-06-12	下午	2	25	0	25	20.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
447	7	21	5	2026-06-12	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
448	7	22	5	2026-06-13	上午	1	50	0	50	15.00	正常	周六仅上午出诊，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
449	7	23	5	2026-06-14	上午	1	50	0	50	15.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
450	7	25	5	2026-06-14	下午	3	30	0	30	30.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
451	7	24	5	2026-06-15	上午	2	25	0	25	20.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
452	7	21	5	2026-06-15	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
453	7	22	5	2026-06-15	下午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
454	7	23	5	2026-06-15	下午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
455	7	25	5	2026-06-16	上午	3	30	0	30	30.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
456	7	24	5	2026-06-16	上午	2	25	0	25	20.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
457	7	21	5	2026-06-16	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
458	7	22	5	2026-06-16	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
459	7	23	5	2026-06-17	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
460	7	25	5	2026-06-17	上午	3	30	0	30	30.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
461	7	24	5	2026-06-17	下午	2	25	0	25	20.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
462	7	21	5	2026-06-17	下午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
463	7	22	5	2026-06-18	上午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
464	7	23	5	2026-06-18	上午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
465	7	25	5	2026-06-18	下午	3	30	0	30	30.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
466	7	24	5	2026-06-18	下午	2	25	0	25	20.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
467	7	21	5	2026-06-19	上午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
468	7	22	5	2026-06-19	上午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
469	7	23	5	2026-06-19	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
470	7	25	5	2026-06-19	下午	3	30	0	30	30.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
471	7	24	5	2026-06-20	上午	2	25	0	25	20.00	正常	周六仅上午出诊，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
472	7	21	5	2026-06-21	上午	1	50	0	50	15.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
473	7	22	5	2026-06-21	下午	1	50	0	50	15.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
474	7	23	5	2026-06-22	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
475	7	25	5	2026-06-22	上午	3	30	0	30	30.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
476	7	24	5	2026-06-22	下午	2	25	0	25	20.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
477	7	21	5	2026-06-22	下午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
478	7	22	5	2026-06-23	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
479	7	23	5	2026-06-23	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
480	7	25	5	2026-06-23	下午	3	30	0	30	30.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
481	7	24	5	2026-06-23	下午	2	25	0	25	20.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
482	7	21	5	2026-06-24	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
483	7	22	5	2026-06-24	上午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
484	7	23	5	2026-06-24	下午	1	50	0	50	15.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
485	7	25	5	2026-06-24	下午	3	30	0	30	30.00	正常	周三需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
486	7	24	5	2026-06-25	上午	2	25	0	25	20.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
487	7	21	5	2026-06-25	上午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
488	7	22	5	2026-06-25	下午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
489	7	23	5	2026-06-25	下午	1	50	0	50	15.00	正常	周四需求较低，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
490	7	25	5	2026-06-26	上午	3	30	0	30	30.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
491	7	24	5	2026-06-26	上午	2	25	0	25	20.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
492	7	21	5	2026-06-26	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
493	7	22	5	2026-06-26	下午	1	50	0	50	15.00	正常	周五需求中等，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
494	7	23	5	2026-06-27	上午	1	50	0	50	15.00	正常	周六仅上午出诊，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
495	7	25	5	2026-06-28	上午	3	30	0	30	30.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
496	7	24	5	2026-06-28	下午	2	25	0	25	20.00	正常	法定节假日，配置1人出诊	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
497	7	21	5	2026-06-29	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
498	7	22	5	2026-06-29	上午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
499	7	23	5	2026-06-29	下午	1	50	0	50	15.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
500	7	25	5	2026-06-29	下午	3	30	0	30	30.00	正常	周一需求高，号源充足	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
501	7	24	5	2026-06-30	上午	2	25	0	25	20.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
502	7	21	5	2026-06-30	上午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
503	7	22	5	2026-06-30	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
504	7	23	5	2026-06-30	下午	1	50	0	50	15.00	正常	周二需求较高，配置合理	f	\N	2026-06-11 14:16:14.489182	2026-06-11 14:16:14.489182	0
257	5	42	9	2026-06-16	下午	1	50	1	49	15.00	正常	满足就诊需求	f	\N	2026-06-09 15:48:50.985394	2026-06-15 18:30:08.551596	0
\.


--
-- Data for Name: drug_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.drug_info (id, drug_code, drug_name, drug_format, drug_unit, manufacturer, drug_dosage, drug_type, drug_price, mnemonic_code, creation_date, name, generic_name, brand_name, specification, dosage_form, unit, approval_number, price, stock_quantity, low_stock_threshold, storage_conditions, instructions, contraindications, adverse_reactions, status, create_time, update_time) FROM stdin;
1	ASP001	阿司匹林肠溶片	100mg*30片/盒	盒	拜耳医药	片剂	西药	25.80	ASPL	2026-05-27	阿司匹林肠溶片	\N	\N	100mg*30片/盒	片剂	盒	ASP001	25.80	100	20	\N	西药	\N	\N	1	2026-06-15 13:30:05.080929	2026-06-15 13:30:05.083238
2	BLF001	布洛芬缓释胶囊	0.3g*20粒/盒	盒	中美史克	胶囊	西药	18.50	BLF	2026-05-27	布洛芬缓释胶囊	\N	\N	0.3g*20粒/盒	胶囊	盒	BLF001	18.50	100	20	\N	西药	\N	\N	1	2026-06-15 13:30:05.080929	2026-06-15 13:30:05.083238
3	AMX001	阿莫西林胶囊	0.25g*24粒/盒	盒	哈药集团	胶囊	西药	16.00	AMXL	2026-05-27	阿莫西林胶囊	\N	\N	0.25g*24粒/盒	胶囊	盒	AMX001	16.00	100	20	\N	西药	\N	\N	1	2026-06-15 13:30:05.080929	2026-06-15 13:30:05.083238
\.


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, deptment_id, regist_level_id, realname, password, delmark) FROM stdin;
1	1	1	内科张医生	dev-password	0
2	1	1	内科李医生	dev-password	0
3	1	1	内科王医生	dev-password	0
4	1	2	内科赵专家	dev-password	0
5	1	3	内科刘主任	dev-password	0
6	2	1	呼吸内科周医生	dev-password	0
7	2	1	呼吸内科吴医生	dev-password	0
8	2	1	呼吸内科郑医生	dev-password	0
9	2	2	呼吸内科冯专家	dev-password	0
10	2	3	呼吸内科陈主任	dev-password	0
11	3	1	心血管内科孙医生	dev-password	0
12	3	1	心血管内科李医生	dev-password	0
13	3	1	心血管内科林医生	dev-password	0
14	3	2	心血管内科何专家	dev-password	0
15	3	3	心血管内科高主任	dev-password	0
16	4	1	消化内科马医生	dev-password	0
17	4	1	消化内科朱医生	dev-password	0
18	4	1	消化内科秦医生	dev-password	0
19	4	2	消化内科尤专家	dev-password	0
20	4	3	消化内科许主任	dev-password	0
21	5	1	神经内科施医生	dev-password	0
22	5	1	神经内科张医生	dev-password	0
23	5	1	神经内科蒋医生	dev-password	0
24	5	2	神经内科韩专家	dev-password	0
25	5	3	神经内科沈主任	dev-password	0
26	6	1	肾内科唐医生	dev-password	0
27	6	1	肾内科冯医生	dev-password	0
28	6	1	肾内科董医生	dev-password	0
29	6	2	肾内科潘专家	dev-password	0
30	6	3	肾内科姜主任	dev-password	0
31	7	1	内分泌科苏医生	dev-password	0
32	7	1	内分泌科魏医生	dev-password	0
33	7	1	内分泌科卢医生	dev-password	0
34	7	2	内分泌科崔专家	dev-password	0
35	7	3	内分泌科蔡主任	dev-password	0
36	8	1	外科丁医生	dev-password	0
37	8	1	外科沈医生	dev-password	0
38	8	1	外科徐医生	dev-password	0
39	8	2	外科蒋专家	dev-password	0
40	8	3	外科沈主任	dev-password	0
41	9	1	骨科卢医生	dev-password	0
42	9	1	骨科马医生	dev-password	0
43	9	1	骨科龚医生	dev-password	0
44	9	2	骨科秦专家	dev-password	0
45	9	3	骨科谢主任	dev-password	0
46	10	1	妇产科苏医生	dev-password	0
47	10	1	妇产科韦医生	dev-password	0
48	10	1	妇产科严医生	dev-password	0
49	10	2	妇产科卫专家	dev-password	0
50	10	3	妇产科武主任	dev-password	0
51	11	1	儿科陶医生	dev-password	0
52	11	1	儿科俞医生	dev-password	0
53	11	1	儿科任医生	dev-password	0
54	11	2	儿科袁专家	dev-password	0
55	11	3	儿科柳主任	dev-password	0
56	12	1	新生儿科毕医生	dev-password	0
57	12	1	新生儿科郝医生	dev-password	0
58	12	1	新生儿科邬医生	dev-password	0
59	12	2	新生儿科安专家	dev-password	0
60	12	3	新生儿科常主任	dev-password	0
61	13	1	眼科乐医生	dev-password	0
62	13	1	眼科于医生	dev-password	0
63	13	1	眼科傅医生	dev-password	0
64	13	2	眼科康专家	dev-password	0
65	13	3	眼科陆主任	dev-password	0
66	14	1	耳鼻咽喉科柴医生	dev-password	0
67	14	1	耳鼻咽喉科胡医生	dev-password	0
68	14	1	耳鼻咽喉科戴医生	dev-password	0
69	14	2	耳鼻咽喉科蔡专家	dev-password	0
70	14	3	耳鼻咽喉科谭主任	dev-password	0
71	15	1	口腔科舒医生	dev-password	0
72	15	1	口腔科屈医生	dev-password	0
73	15	1	口腔科项医生	dev-password	0
74	15	2	口腔科纪专家	dev-password	0
75	15	3	口腔科梁主任	dev-password	0
76	16	1	皮肤科杜医生	dev-password	0
77	16	1	皮肤科阮医生	dev-password	0
78	16	1	皮肤科贝医生	dev-password	0
79	16	2	皮肤科明专家	dev-password	0
80	16	3	皮肤科程主任	dev-password	0
81	17	1	中医科卫医生	dev-password	0
82	17	1	中医科申医生	dev-password	0
83	17	1	中医科连医生	dev-password	0
84	17	2	中医科习专家	dev-password	0
85	17	3	中医科程主任	dev-password	0
86	18	1	肿瘤科向医生	dev-password	0
87	18	1	肿瘤科丁医生	dev-password	0
88	18	1	肿瘤科茅医生	dev-password	0
89	18	2	肿瘤科左专家	dev-password	0
90	18	3	肿瘤科甘主任	dev-password	0
91	19	1	急诊科龙医生	dev-password	0
92	19	1	急诊科万医生	dev-password	0
93	19	1	急诊科柯医生	dev-password	0
94	19	2	急诊科柯专家	dev-password	0
95	19	3	急诊科支主任	dev-password	0
96	20	1	康复科管医生	dev-password	0
97	20	1	康复科蔡医生	dev-password	0
98	20	1	康复科蒙医生	dev-password	0
99	20	2	康复科应专家	dev-password	0
100	20	3	康复科丁主任	dev-password	0
101	35	\N	放射科技师王一	dev-password	0
102	35	\N	放射科技师李二	dev-password	0
103	35	\N	放射科医生张三	dev-password	0
104	36	\N	超声科技师赵四	dev-password	0
105	36	\N	超声科医生钱五	dev-password	0
106	37	\N	检验科技师孙六	dev-password	0
107	37	\N	检验科医生周七	dev-password	0
108	38	\N	输血科技师吴八	dev-password	0
109	39	\N	病理科医生郑九	dev-password	0
110	40	\N	处置室护士长冯十	dev-password	0
111	40	\N	处置室护士李一	dev-password	0
112	41	\N	内镜中心技师周二	dev-password	0
113	41	\N	内镜中心医生陈二	dev-password	0
114	42	\N	手术室护士长周三	dev-password	0
115	42	\N	手术室麻醉师李三	dev-password	0
116	44	\N	供应中心护士长王四	dev-password	0
117	45	\N	药房药师张五	dev-password	0
118	45	\N	药房药师赵六	dev-password	0
\.


--
-- Data for Name: expense_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expense_record (id, register_id, patient_id, patient_name, category_id, category_name, item_id, item_name, item_code, quantity, unit_price, total_amount, status, pay_time, refund_time, operator_id, operator_name, remark, create_time) FROM stdin;
1	3	9	王皞楠	\N	挂号费	1	普通号挂号费	REGISTRATION_FEE	1	15.00	15.00	2	2026-06-09 19:52:18.750821	2026-06-10 18:07:27.579535	9	患者退号	患者取消挂号自动退款	2026-06-09 19:52:18.577798
2	4	9	王皞楠	\N	挂号费	2	专家号挂号费	REGISTRATION_FEE	1	20.00	20.00	2	2026-06-10 19:27:10.116449	2026-06-10 19:28:22.425466	9	患者退号	患者取消挂号自动退款	2026-06-10 19:27:10.006284
3	5	9	王皞楠	\N	挂号费	2	专家号挂号费	REGISTRATION_FEE	1	20.00	20.00	1	2026-06-10 20:04:46.854262	\N	\N	患者余额	患者账户余额自动支付	2026-06-10 20:04:46.665871
4	6	9	王皞楠	\N	挂号费	3	主任医师号挂号费	REGISTRATION_FEE	1	30.00	30.00	1	2026-06-11 10:14:15.997903	\N	\N	患者余额	患者账户余额自动支付	2026-06-11 10:14:15.482948
5	7	9	王皞楠	\N	挂号费	1	普通号挂号费	REGISTRATION_FEE	1	15.00	15.00	1	2026-06-15 18:30:08.531032	\N	\N	患者余额	患者账户余额自动支付	2026-06-15 18:30:08.327588
\.


--
-- Data for Name: inspection_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_request (id, register_id, medical_technology_id, inspection_info, inspection_position, creation_time, inspection_employee_id, inputinspection_employee_id, inspection_time, inspection_result, inspection_state, inspection_remark) FROM stdin;
\.


--
-- Data for Name: leave_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_request (id, physician_id, leave_date, time_slot, leave_type, reason, ai_parsed_date, ai_parsed_slot, ai_confidence, status, approver_id, approval_time, auto_processed, create_time, delmark) FROM stdin;
\.


--
-- Data for Name: medical_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medical_record (id, register_id, readme, present, present_treat, history, allergy, physique, proposal, careful, diagnosis, cure) FROM stdin;
\.


--
-- Data for Name: medical_record_disease; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medical_record_disease (medical_record_id, disease_id) FROM stdin;
\.


--
-- Data for Name: medical_technology; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medical_technology (id, tech_code, tech_name, tech_format, tech_price, tech_type, price_type, deptment_id, name, code, type, department_id, department_name, price, specimen_type, container, instructions, preparation, turnaround_time, status, description, create_time, update_time) FROM stdin;
2	TLCT	头颅CT	平扫	260.00	check	检查费	3	头颅CT	TLCT	check	3	心血管内科	260.00	\N	\N	平扫	\N	\N	1	检查费	2026-06-15 13:30:05.173908	2026-06-15 13:30:05.177579
1	XJCT	胸部CT	平扫	280.00	check	检查费	3	胸部CT	XJCT	check	3	心血管内科	280.00	\N	\N	平扫	\N	\N	1	检查费	2026-06-15 13:30:05.173908	2026-06-15 13:30:05.177579
4	CRP	C反应蛋白	血清	45.00	inspection	检验费	4	C反应蛋白	CRP	inspection	4	消化内科	45.00	\N	\N	血清	\N	\N	1	检验费	2026-06-15 13:30:05.173908	2026-06-15 13:30:05.177579
3	XCG	血常规	全血	35.00	inspection	检验费	4	血常规	XCG	inspection	4	消化内科	35.00	\N	\N	全血	\N	\N	1	检验费	2026-06-15 13:30:05.173908	2026-06-15 13:30:05.177579
5	WX	雾化吸入	次	30.00	disposal	处置费	5	雾化吸入	WX	disposal	5	神经内科	30.00	\N	\N	次	\N	\N	1	处置费	2026-06-15 13:30:05.173908	2026-06-15 13:30:05.177579
\.


--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient (id, real_name, id_card, gender, birthdate, phone, avatar, home_address, allergy_history, delmark, create_time, update_time, account_balance) FROM stdin;
2	张小华	210102196503151234	女	1965-03-15	13900139000	\N	\N	无	1	2026-06-04 10:18:34.233319	2026-06-04 10:18:34.233319	0.00
3	李建国	210102196203201234	男	1962-03-20	13900139001	\N	\N	磺胺类过敏	1	2026-06-04 10:18:34.236532	2026-06-04 10:18:34.236532	0.00
1	李小明	210102199001011234	男	1990-01-01	13800138000	\N	\N	青霉素过敏	1	2026-06-04 10:18:34.228829	2026-06-04 10:18:34.228829	0.00
10	王佳琳	21132420051203302X	女	\N	15040221359	\N	\N	\N	0	2026-06-05 13:34:09.984767	2026-06-05 18:04:46.343085	0.00
11	王佳琳	21132420051203302X	女	\N	15040221359	\N	\N	\N	1	2026-06-05 18:06:28.730453	2026-06-05 18:06:28.730453	0.00
9	王皞楠	210882200504260011	男	2005-04-26	15041746275	\N	辽宁省营口市大石桥市	头孢过敏	1	2026-06-04 16:06:13.116521	2026-06-15 18:30:08.479181	35.00
\.


--
-- Data for Name: patient_balance_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_balance_transaction (id, transaction_no, patient_id, transaction_type, amount, balance_before, balance_after, business_type, business_id, operator_id, operator_name, remark, transaction_time, create_time) FROM stdin;
1	RC1781090337876482557A4	9	RECHARGE	100.00	415.00	515.00	RECHARGE	\N	\N	患者自助	账户充值	2026-06-10 19:18:57.876169	2026-06-10 19:18:57.874493
2	DT17810908301016FFEBE56	9	DEDUCT	20.00	515.00	495.00	REGISTRATION	4	9	患者余额	挂号时自动使用余额支付	2026-06-10 19:27:10.101942	2026-06-10 19:27:10.094765
3	RF17810909023930E2BFA85	9	REFUND	20.00	495.00	515.00	REGISTRATION	4	9	患者退号	患者取消挂号自动退款	2026-06-10 19:28:22.393472	2026-06-10 19:28:22.381411
4	DT178109308682688FEFA4E	9	DEDUCT	20.00	100.00	80.00	REGISTRATION	5	9	患者余额	挂号时自动使用余额支付	2026-06-10 20:04:46.827073	2026-06-10 20:04:46.803658
5	DT17811440558844BBAED19	9	DEDUCT	30.00	80.00	50.00	REGISTRATION	6	9	患者余额	挂号时自动使用余额支付	2026-06-11 10:14:15.891089	2026-06-11 10:14:15.848992
6	DT17815194084912A0B5D49	9	DEDUCT	15.00	50.00	35.00	REGISTRATION	7	9	患者余额	挂号时自动使用余额支付	2026-06-15 18:30:08.491691	2026-06-15 18:30:08.479181
\.


--
-- Data for Name: prescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prescription (id, register_id, drug_id, drug_usage, drug_number, creation_time, drug_state) FROM stdin;
\.


--
-- Data for Name: regist_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regist_level (id, regist_code, regist_name, regist_fee, regist_quota, sequence_no, delmark) FROM stdin;
1	PT	普通号	5.00	50	1	0
2	ZJ	专家号	15.00	20	2	0
3	ZR	主任医师号	30.00	15	3	0
\.


--
-- Data for Name: register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.register (id, case_number, real_name, gender, card_number, birthdate, age, age_type, home_address, visit_date, noon, deptment_id, employee_id, regist_level_id, settle_category_id, is_book, regist_method, regist_money, visit_state, patient_id, scheduling_id, check_in_time) FROM stdin;
3	BL20260609635	王皞楠	男	\N	\N	\N	\N	\N	2026-06-09 00:00:00	下午	1	3	1	1	否	线上	15.00	4	9	135	\N
4	BL20260610360	王皞楠	男	\N	\N	\N	\N	\N	2026-06-11 00:00:00	下午	3	14	2	1	否	线上	20.00	4	9	342	\N
5	BL20260610361	王皞楠	男	\N	\N	\N	\N	\N	2026-06-11 00:00:00	上午	1	4	2	1	否	线上	20.00	5	9	140	\N
6	BL20260611159	王皞楠	男	\N	\N	\N	\N	\N	2026-06-11 00:00:00	上午	3	15	3	1	否	线上	30.00	5	9	340	\N
7	BL20260615523	王皞楠	男	\N	\N	\N	\N	\N	2026-06-16 00:00:00	下午	9	42	1	1	否	线上	15.00	1	9	257	\N
\.


--
-- Data for Name: schedule_adjust_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_adjust_log (id, schedule_id, field_name, old_value, new_value, adjust_type, adjust_by, adjust_time, remark, delmark) FROM stdin;
\.


--
-- Data for Name: schedule_adjust_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_adjust_request (id, schedule_id, adjust_type, old_physician_id, new_physician_id, old_status, new_status, old_quota, new_quota, reason, ai_suggestion, affect_patients, triggered_by, status, confirmed_by, confirm_time, confirm_remark, create_time, delmark) FROM stdin;
\.


--
-- Data for Name: schedule_plan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_plan (id, plan_name, department_id, plan_month, status, ai_generated, ai_version, total_schedules, total_quota, created_by, created_time, published_time, published_by, delmark) FROM stdin;
1	消化内科2026年6月排班	4	2026-06	草稿	f	\N	0	0	\N	2026-06-06 10:45:57.770051	\N	\N	0
2	内科2026-06排班	1	2026-06	已发布	f	\N	\N	\N	\N	2026-06-08 18:04:40.542017	2026-06-08 18:04:52.210228	1	0
3	内科2026-07排班	1	2026-07	草稿	t	1	104	4210	1	2026-06-09 10:35:15.677022	\N	\N	0
4	内科2026-06排班	1	2026-06	已发布	t	1	100	4280	1	2026-06-09 13:55:17.017958	2026-06-09 17:45:18.399605	1	0
6	心血管内科2026-06排班	3	2026-06	已发布	t	1	100	3940	1	2026-06-10 18:21:58.591426	2026-06-10 19:26:07.84532	1	0
7	神经内科2026-06排班	5	2026-06	已发布	t	1	100	4100	1	2026-06-11 14:16:14.489182	2026-06-11 14:16:36.146969	1	0
5	骨科2026-06排班	9	2026-06	已发布	t	1	100	4440	1	2026-06-09 15:48:50.985394	2026-06-15 18:29:14.56554	1	0
\.


--
-- Data for Name: settle_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settle_category (id, settle_code, settle_name, sequence_no, delmark) FROM stdin;
1	ZF	自费	1	0
\.


--
-- Data for Name: triage_desk_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.triage_desk_record (id, patient_id, patient_name, patient_phone, symptoms, ai_triage_result, recommended_department_id, recommended_department, recommended_physician_id, recommended_physician_name, risk_level, ai_analysis, status, confirmed_department_id, confirmed_department, confirmed_physician_id, confirmed_physician_name, operator_id, operator_name, confirm_remark, create_time, confirm_time) FROM stdin;
\.


--
-- Data for Name: user_patient_managed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_patient_managed (user_id, patient_id, create_time, relation) FROM stdin;
6	1	2026-06-04 10:18:34.23785	本人
15	9	2026-06-04 16:06:13.116521	本人
6	2	2026-06-04 10:18:34.240934	母亲
6	3	2026-06-04 10:18:34.242599	父亲
15	10	2026-06-05 13:34:10.009934	配偶
15	11	2026-06-05 18:06:28.743294	配偶
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, real_name, email, phone, status, user_type, remark, create_time, update_time) FROM stdin;
1	admin	admin123	系统管理员	\N	\N	1	1	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
2	doctor1	doctor123	张医生	\N	\N	1	2	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
3	reg001	reg123	李收费	\N	\N	1	3	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
4	medtech01	medtech123	王技师	\N	\N	1	4	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
5	pharma01	pharma123	赵药师	\N	\N	1	5	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
6	patient001	patient123	小明	\N	\N	1	6	\N	2026-05-28 15:39:21.15453	2026-05-28 15:39:21.15453
15	shanluo	123456	王皞楠	\N	15041746275	1	6	\N	2026-06-04 16:06:13.116521	2026-06-05 17:57:17.257478
\.


--
-- Name: ai_consultation_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_consultation_record_id_seq', 16, true);


--
-- Name: ai_diagnosis_suggestion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_diagnosis_suggestion_id_seq', 1, false);


--
-- Name: ai_exam_analysis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_exam_analysis_id_seq', 1, false);


--
-- Name: ai_exam_suggestion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_exam_suggestion_id_seq', 1, false);


--
-- Name: ai_follow_up_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_follow_up_plan_id_seq', 1, false);


--
-- Name: ai_follow_up_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_follow_up_record_id_seq', 1, false);


--
-- Name: ai_medical_record_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_medical_record_log_id_seq', 1, false);


--
-- Name: ai_prescription_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_prescription_review_id_seq', 1, false);


--
-- Name: ai_triage_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_triage_record_id_seq', 31, true);


--
-- Name: check_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.check_request_id_seq', 1, false);


--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_id_seq', 44, true);


--
-- Name: disease_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.disease_id_seq', 1, false);


--
-- Name: disposal_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.disposal_request_id_seq', 1, false);


--
-- Name: doctor_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctor_schedule_id_seq', 504, true);


--
-- Name: drug_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.drug_info_id_seq', 1, false);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_id_seq', 118, true);


--
-- Name: expense_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expense_record_id_seq', 5, true);


--
-- Name: inspection_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inspection_request_id_seq', 1, false);


--
-- Name: leave_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leave_request_id_seq', 1, false);


--
-- Name: medical_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medical_record_id_seq', 1, false);


--
-- Name: medical_technology_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medical_technology_id_seq', 1, false);


--
-- Name: patient_balance_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_balance_transaction_id_seq', 6, true);


--
-- Name: patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_id_seq', 11, true);


--
-- Name: prescription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prescription_id_seq', 1, false);


--
-- Name: regist_level_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.regist_level_id_seq', 1, false);


--
-- Name: register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.register_id_seq', 7, true);


--
-- Name: schedule_adjust_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_adjust_log_id_seq', 1, false);


--
-- Name: schedule_adjust_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_adjust_request_id_seq', 1, false);


--
-- Name: schedule_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_plan_id_seq', 7, true);


--
-- Name: settle_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settle_category_id_seq', 1, false);


--
-- Name: triage_desk_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.triage_desk_record_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 15, true);


--
-- Name: ai_consultation_record ai_consultation_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_consultation_record
    ADD CONSTRAINT ai_consultation_record_pkey PRIMARY KEY (id);


--
-- Name: ai_diagnosis_suggestion ai_diagnosis_suggestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_diagnosis_suggestion
    ADD CONSTRAINT ai_diagnosis_suggestion_pkey PRIMARY KEY (id);


--
-- Name: ai_exam_analysis ai_exam_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_analysis
    ADD CONSTRAINT ai_exam_analysis_pkey PRIMARY KEY (id);


--
-- Name: ai_exam_suggestion ai_exam_suggestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_suggestion
    ADD CONSTRAINT ai_exam_suggestion_pkey PRIMARY KEY (id);


--
-- Name: ai_follow_up_plan ai_follow_up_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_plan
    ADD CONSTRAINT ai_follow_up_plan_pkey PRIMARY KEY (id);


--
-- Name: ai_follow_up_record ai_follow_up_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_record
    ADD CONSTRAINT ai_follow_up_record_pkey PRIMARY KEY (id);


--
-- Name: ai_medical_record_log ai_medical_record_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_medical_record_log
    ADD CONSTRAINT ai_medical_record_log_pkey PRIMARY KEY (id);


--
-- Name: ai_prescription_review ai_prescription_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_prescription_review
    ADD CONSTRAINT ai_prescription_review_pkey PRIMARY KEY (id);


--
-- Name: ai_triage_record ai_triage_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_triage_record
    ADD CONSTRAINT ai_triage_record_pkey PRIMARY KEY (id);


--
-- Name: check_request check_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request
    ADD CONSTRAINT check_request_pkey PRIMARY KEY (id);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id);


--
-- Name: disease disease_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disease
    ADD CONSTRAINT disease_pkey PRIMARY KEY (id);


--
-- Name: disposal_request disposal_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request
    ADD CONSTRAINT disposal_request_pkey PRIMARY KEY (id);


--
-- Name: doctor_schedule doctor_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule
    ADD CONSTRAINT doctor_schedule_pkey PRIMARY KEY (id);


--
-- Name: drug_info drug_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drug_info
    ADD CONSTRAINT drug_info_pkey PRIMARY KEY (id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: expense_record expense_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expense_record
    ADD CONSTRAINT expense_record_pkey PRIMARY KEY (id);


--
-- Name: inspection_request inspection_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request
    ADD CONSTRAINT inspection_request_pkey PRIMARY KEY (id);


--
-- Name: leave_request leave_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_request
    ADD CONSTRAINT leave_request_pkey PRIMARY KEY (id);


--
-- Name: medical_record_disease medical_record_disease_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record_disease
    ADD CONSTRAINT medical_record_disease_pkey PRIMARY KEY (medical_record_id, disease_id);


--
-- Name: medical_record medical_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record
    ADD CONSTRAINT medical_record_pkey PRIMARY KEY (id);


--
-- Name: medical_technology medical_technology_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_technology
    ADD CONSTRAINT medical_technology_pkey PRIMARY KEY (id);


--
-- Name: patient_balance_transaction patient_balance_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_balance_transaction
    ADD CONSTRAINT patient_balance_transaction_pkey PRIMARY KEY (id);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (id);


--
-- Name: prescription prescription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prescription
    ADD CONSTRAINT prescription_pkey PRIMARY KEY (id);


--
-- Name: regist_level regist_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regist_level
    ADD CONSTRAINT regist_level_pkey PRIMARY KEY (id);


--
-- Name: register register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register
    ADD CONSTRAINT register_pkey PRIMARY KEY (id);


--
-- Name: schedule_adjust_log schedule_adjust_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_log
    ADD CONSTRAINT schedule_adjust_log_pkey PRIMARY KEY (id);


--
-- Name: schedule_adjust_request schedule_adjust_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_request
    ADD CONSTRAINT schedule_adjust_request_pkey PRIMARY KEY (id);


--
-- Name: schedule_plan schedule_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_plan
    ADD CONSTRAINT schedule_plan_pkey PRIMARY KEY (id);


--
-- Name: settle_category settle_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settle_category
    ADD CONSTRAINT settle_category_pkey PRIMARY KEY (id);


--
-- Name: triage_desk_record triage_desk_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triage_desk_record
    ADD CONSTRAINT triage_desk_record_pkey PRIMARY KEY (id);


--
-- Name: department uk_department_dept_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT uk_department_dept_code UNIQUE (dept_code);


--
-- Name: disease uk_disease_icd; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disease
    ADD CONSTRAINT uk_disease_icd UNIQUE (diseaseicd);


--
-- Name: drug_info uk_drug_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drug_info
    ADD CONSTRAINT uk_drug_code UNIQUE (drug_code);


--
-- Name: medical_record uk_medical_record_register; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record
    ADD CONSTRAINT uk_medical_record_register UNIQUE (register_id);


--
-- Name: medical_technology uk_medtech_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_technology
    ADD CONSTRAINT uk_medtech_code UNIQUE (tech_code);


--
-- Name: patient_balance_transaction uk_patient_balance_transaction_no; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_balance_transaction
    ADD CONSTRAINT uk_patient_balance_transaction_no UNIQUE (transaction_no);


--
-- Name: regist_level uk_regist_level_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regist_level
    ADD CONSTRAINT uk_regist_level_code UNIQUE (regist_code);


--
-- Name: settle_category uk_settle_category_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settle_category
    ADD CONSTRAINT uk_settle_category_code UNIQUE (settle_code);


--
-- Name: user_patient_managed user_patient_managed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_patient_managed
    ADD CONSTRAINT user_patient_managed_pkey PRIMARY KEY (user_id, patient_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_ai_consult_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_consult_patient_id ON public.ai_consultation_record USING btree (patient_id);


--
-- Name: idx_ai_consult_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_consult_register_id ON public.ai_consultation_record USING btree (register_id);


--
-- Name: idx_ai_consult_session_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_consult_session_uuid ON public.ai_consultation_record USING btree (session_uuid);


--
-- Name: idx_ai_consult_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_consult_state ON public.ai_consultation_record USING btree (consultation_state);


--
-- Name: idx_ai_diagnosis_disease_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_diagnosis_disease_id ON public.ai_diagnosis_suggestion USING btree (disease_id);


--
-- Name: idx_ai_diagnosis_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_diagnosis_register_id ON public.ai_diagnosis_suggestion USING btree (register_id);


--
-- Name: idx_ai_exam_analysis_check_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_exam_analysis_check_id ON public.ai_exam_analysis USING btree (check_request_id);


--
-- Name: idx_ai_exam_analysis_inspection_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_exam_analysis_inspection_id ON public.ai_exam_analysis USING btree (inspection_request_id);


--
-- Name: idx_ai_exam_analysis_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_exam_analysis_register_id ON public.ai_exam_analysis USING btree (register_id);


--
-- Name: idx_ai_exam_analysis_risk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_exam_analysis_risk ON public.ai_exam_analysis USING btree (risk_level);


--
-- Name: idx_ai_exam_sug_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_exam_sug_register_id ON public.ai_exam_suggestion USING btree (register_id);


--
-- Name: idx_ai_followup_planned_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_followup_planned_date ON public.ai_follow_up_plan USING btree (planned_date);


--
-- Name: idx_ai_followup_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_followup_register_id ON public.ai_follow_up_plan USING btree (register_id);


--
-- Name: idx_ai_followup_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_followup_status ON public.ai_follow_up_plan USING btree (plan_status);


--
-- Name: idx_ai_fur_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_fur_plan_id ON public.ai_follow_up_record USING btree (follow_up_plan_id);


--
-- Name: idx_ai_fur_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_fur_register_id ON public.ai_follow_up_record USING btree (register_id);


--
-- Name: idx_ai_mrlog_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_mrlog_register_id ON public.ai_medical_record_log USING btree (register_id);


--
-- Name: idx_ai_review_prescription_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_review_prescription_id ON public.ai_prescription_review USING btree (prescription_id);


--
-- Name: idx_ai_review_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_review_register_id ON public.ai_prescription_review USING btree (register_id);


--
-- Name: idx_ai_review_result; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_review_result ON public.ai_prescription_review USING btree (review_result);


--
-- Name: idx_ai_triage_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_triage_register_id ON public.ai_triage_record USING btree (register_id);


--
-- Name: idx_ai_triage_risk_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_triage_risk_level ON public.ai_triage_record USING btree (risk_level);


--
-- Name: idx_ai_triage_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_triage_time ON public.ai_triage_record USING btree (triage_time);


--
-- Name: idx_check_request_medtech_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_check_request_medtech_id ON public.check_request USING btree (medical_technology_id);


--
-- Name: idx_check_request_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_check_request_register_id ON public.check_request USING btree (register_id);


--
-- Name: idx_check_request_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_check_request_state ON public.check_request USING btree (check_state);


--
-- Name: idx_disease_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disease_category ON public.disease USING btree (disease_category);


--
-- Name: idx_disease_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disease_name ON public.disease USING btree (disease_name);


--
-- Name: idx_disposal_request_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disposal_request_register_id ON public.disposal_request USING btree (register_id);


--
-- Name: idx_disposal_request_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disposal_request_state ON public.disposal_request USING btree (disposal_state);


--
-- Name: idx_drug_info_low_stock; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_info_low_stock ON public.drug_info USING btree (status, stock_quantity);


--
-- Name: idx_drug_info_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_info_name ON public.drug_info USING btree (name);


--
-- Name: idx_drug_info_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_info_status ON public.drug_info USING btree (status);


--
-- Name: idx_drug_mnemonic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_mnemonic ON public.drug_info USING btree (mnemonic_code);


--
-- Name: idx_drug_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_name ON public.drug_info USING btree (drug_name);


--
-- Name: idx_drug_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_drug_type ON public.drug_info USING btree (drug_type);


--
-- Name: idx_ds_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ds_date ON public.doctor_schedule USING btree (work_date);


--
-- Name: idx_ds_department; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ds_department ON public.doctor_schedule USING btree (department_id);


--
-- Name: idx_ds_physician; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ds_physician ON public.doctor_schedule USING btree (physician_id);


--
-- Name: idx_ds_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ds_plan ON public.doctor_schedule USING btree (plan_id);


--
-- Name: idx_ds_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_ds_unique ON public.doctor_schedule USING btree (work_date, physician_id, time_slot) WHERE (delmark = 0);


--
-- Name: idx_employee_deptment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_deptment_id ON public.employee USING btree (deptment_id);


--
-- Name: idx_employee_regist_level_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_regist_level_id ON public.employee USING btree (regist_level_id);


--
-- Name: idx_expense_record_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expense_record_patient_id ON public.expense_record USING btree (patient_id);


--
-- Name: idx_expense_record_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expense_record_register_id ON public.expense_record USING btree (register_id);


--
-- Name: idx_expense_record_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expense_record_status ON public.expense_record USING btree (status);


--
-- Name: idx_expense_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expense_register_id ON public.expense_record USING btree (register_id);


--
-- Name: idx_expense_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expense_status ON public.expense_record USING btree (status);


--
-- Name: idx_inspection_request_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inspection_request_register_id ON public.inspection_request USING btree (register_id);


--
-- Name: idx_inspection_request_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inspection_request_state ON public.inspection_request USING btree (inspection_state);


--
-- Name: idx_lr_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lr_date ON public.leave_request USING btree (leave_date);


--
-- Name: idx_lr_physician; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lr_physician ON public.leave_request USING btree (physician_id);


--
-- Name: idx_lr_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lr_status ON public.leave_request USING btree (status);


--
-- Name: idx_medtech_dept_new; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_dept_new ON public.medical_technology USING btree (department_id);


--
-- Name: idx_medtech_deptment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_deptment_id ON public.medical_technology USING btree (deptment_id);


--
-- Name: idx_medtech_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_name ON public.medical_technology USING btree (name);


--
-- Name: idx_medtech_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_status ON public.medical_technology USING btree (status);


--
-- Name: idx_medtech_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_type ON public.medical_technology USING btree (tech_type);


--
-- Name: idx_medtech_type_new; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medtech_type_new ON public.medical_technology USING btree (type);


--
-- Name: idx_patient_account_balance; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_account_balance ON public.patient USING btree (account_balance);


--
-- Name: idx_patient_balance_transaction_business; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_balance_transaction_business ON public.patient_balance_transaction USING btree (patient_id, transaction_type, business_type, business_id);


--
-- Name: idx_patient_balance_transaction_patient_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_balance_transaction_patient_time ON public.patient_balance_transaction USING btree (patient_id, transaction_time DESC);


--
-- Name: idx_patient_id_card; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_id_card ON public.patient USING btree (id_card);


--
-- Name: idx_prescription_drug_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prescription_drug_id ON public.prescription USING btree (drug_id);


--
-- Name: idx_prescription_register_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prescription_register_id ON public.prescription USING btree (register_id);


--
-- Name: idx_prescription_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prescription_state ON public.prescription USING btree (drug_state);


--
-- Name: idx_register_case_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_case_number ON public.register USING btree (case_number);


--
-- Name: idx_register_deptment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_deptment_id ON public.register USING btree (deptment_id);


--
-- Name: idx_register_employee_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_employee_id ON public.register USING btree (employee_id);


--
-- Name: idx_register_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_patient_id ON public.register USING btree (patient_id);


--
-- Name: idx_register_real_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_real_name ON public.register USING btree (real_name);


--
-- Name: idx_register_scheduling_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_scheduling_id ON public.register USING btree (scheduling_id);


--
-- Name: idx_register_visit_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_visit_date ON public.register USING btree (visit_date);


--
-- Name: idx_register_visit_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_register_visit_state ON public.register USING btree (visit_state);


--
-- Name: idx_sal_adjust_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sal_adjust_by ON public.schedule_adjust_log USING btree (adjust_by);


--
-- Name: idx_sal_schedule; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sal_schedule ON public.schedule_adjust_log USING btree (schedule_id);


--
-- Name: idx_sar_schedule; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sar_schedule ON public.schedule_adjust_request USING btree (schedule_id);


--
-- Name: idx_sar_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sar_status ON public.schedule_adjust_request USING btree (status);


--
-- Name: idx_sar_triggered_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sar_triggered_by ON public.schedule_adjust_request USING btree (triggered_by);


--
-- Name: idx_sp_dept_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sp_dept_month ON public.schedule_plan USING btree (department_id, plan_month);


--
-- Name: idx_sp_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sp_status ON public.schedule_plan USING btree (status);


--
-- Name: idx_triage_desk_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_triage_desk_patient_id ON public.triage_desk_record USING btree (patient_id);


--
-- Name: idx_triage_desk_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_triage_desk_status ON public.triage_desk_record USING btree (status);


--
-- Name: idx_upm_patient; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_upm_patient ON public.user_patient_managed USING btree (patient_id);


--
-- Name: idx_upm_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_upm_user ON public.user_patient_managed USING btree (user_id);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_users_user_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_user_type ON public.users USING btree (user_type);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: uk_patient_balance_transaction_business_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uk_patient_balance_transaction_business_unique ON public.patient_balance_transaction USING btree (patient_id, transaction_type, business_type, business_id) WHERE ((business_type IS NOT NULL) AND (business_id IS NOT NULL));


--
-- Name: ai_consultation_record fk_ai_consult_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_consultation_record
    ADD CONSTRAINT fk_ai_consult_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_diagnosis_suggestion fk_ai_diagnosis_disease; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_diagnosis_suggestion
    ADD CONSTRAINT fk_ai_diagnosis_disease FOREIGN KEY (disease_id) REFERENCES public.disease(id) ON DELETE SET NULL;


--
-- Name: ai_diagnosis_suggestion fk_ai_diagnosis_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_diagnosis_suggestion
    ADD CONSTRAINT fk_ai_diagnosis_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_exam_analysis fk_ai_exam_analysis_check; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_analysis
    ADD CONSTRAINT fk_ai_exam_analysis_check FOREIGN KEY (check_request_id) REFERENCES public.check_request(id) ON DELETE SET NULL;


--
-- Name: ai_exam_analysis fk_ai_exam_analysis_inspection; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_analysis
    ADD CONSTRAINT fk_ai_exam_analysis_inspection FOREIGN KEY (inspection_request_id) REFERENCES public.inspection_request(id) ON DELETE SET NULL;


--
-- Name: ai_exam_analysis fk_ai_exam_analysis_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_analysis
    ADD CONSTRAINT fk_ai_exam_analysis_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_exam_suggestion fk_ai_exam_sug_medtech; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_suggestion
    ADD CONSTRAINT fk_ai_exam_sug_medtech FOREIGN KEY (tech_id) REFERENCES public.medical_technology(id);


--
-- Name: ai_exam_suggestion fk_ai_exam_sug_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_exam_suggestion
    ADD CONSTRAINT fk_ai_exam_sug_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_follow_up_plan fk_ai_followup_prescription; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_plan
    ADD CONSTRAINT fk_ai_followup_prescription FOREIGN KEY (prescription_id) REFERENCES public.prescription(id) ON DELETE SET NULL;


--
-- Name: ai_follow_up_record fk_ai_followup_record_plan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_record
    ADD CONSTRAINT fk_ai_followup_record_plan FOREIGN KEY (follow_up_plan_id) REFERENCES public.ai_follow_up_plan(id);


--
-- Name: ai_follow_up_record fk_ai_followup_record_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_record
    ADD CONSTRAINT fk_ai_followup_record_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_follow_up_plan fk_ai_followup_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_follow_up_plan
    ADD CONSTRAINT fk_ai_followup_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_medical_record_log fk_ai_mrlog_medical_record; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_medical_record_log
    ADD CONSTRAINT fk_ai_mrlog_medical_record FOREIGN KEY (medical_record_id) REFERENCES public.medical_record(id) ON DELETE SET NULL;


--
-- Name: ai_medical_record_log fk_ai_mrlog_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_medical_record_log
    ADD CONSTRAINT fk_ai_mrlog_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_prescription_review fk_ai_review_prescription; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_prescription_review
    ADD CONSTRAINT fk_ai_review_prescription FOREIGN KEY (prescription_id) REFERENCES public.prescription(id);


--
-- Name: ai_prescription_review fk_ai_review_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_prescription_review
    ADD CONSTRAINT fk_ai_review_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: ai_triage_record fk_ai_triage_dept; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_triage_record
    ADD CONSTRAINT fk_ai_triage_dept FOREIGN KEY (recommend_dept_id) REFERENCES public.department(id) ON DELETE SET NULL;


--
-- Name: ai_triage_record fk_ai_triage_doctor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_triage_record
    ADD CONSTRAINT fk_ai_triage_doctor FOREIGN KEY (recommend_doctor_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: ai_triage_record fk_ai_triage_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_triage_record
    ADD CONSTRAINT fk_ai_triage_register FOREIGN KEY (register_id) REFERENCES public.register(id) ON DELETE SET NULL;


--
-- Name: check_request fk_check_request_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request
    ADD CONSTRAINT fk_check_request_employee FOREIGN KEY (check_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: check_request fk_check_request_input_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request
    ADD CONSTRAINT fk_check_request_input_employee FOREIGN KEY (inputcheck_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: check_request fk_check_request_medtech; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request
    ADD CONSTRAINT fk_check_request_medtech FOREIGN KEY (medical_technology_id) REFERENCES public.medical_technology(id);


--
-- Name: check_request fk_check_request_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_request
    ADD CONSTRAINT fk_check_request_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: disposal_request fk_disposal_request_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request
    ADD CONSTRAINT fk_disposal_request_employee FOREIGN KEY (disposal_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: disposal_request fk_disposal_request_input_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request
    ADD CONSTRAINT fk_disposal_request_input_employee FOREIGN KEY (inputdisposal_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: disposal_request fk_disposal_request_medtech; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request
    ADD CONSTRAINT fk_disposal_request_medtech FOREIGN KEY (medical_technology_id) REFERENCES public.medical_technology(id);


--
-- Name: disposal_request fk_disposal_request_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disposal_request
    ADD CONSTRAINT fk_disposal_request_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: doctor_schedule fk_ds_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule
    ADD CONSTRAINT fk_ds_department FOREIGN KEY (department_id) REFERENCES public.department(id);


--
-- Name: doctor_schedule fk_ds_physician; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule
    ADD CONSTRAINT fk_ds_physician FOREIGN KEY (physician_id) REFERENCES public.employee(id);


--
-- Name: doctor_schedule fk_ds_plan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule
    ADD CONSTRAINT fk_ds_plan FOREIGN KEY (plan_id) REFERENCES public.schedule_plan(id);


--
-- Name: doctor_schedule fk_ds_regist_level; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_schedule
    ADD CONSTRAINT fk_ds_regist_level FOREIGN KEY (regist_level_id) REFERENCES public.regist_level(id);


--
-- Name: employee fk_employee_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT fk_employee_department FOREIGN KEY (deptment_id) REFERENCES public.department(id) ON DELETE SET NULL;


--
-- Name: employee fk_employee_regist_level; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT fk_employee_regist_level FOREIGN KEY (regist_level_id) REFERENCES public.regist_level(id) ON DELETE SET NULL;


--
-- Name: inspection_request fk_inspection_request_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request
    ADD CONSTRAINT fk_inspection_request_employee FOREIGN KEY (inspection_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: inspection_request fk_inspection_request_input_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request
    ADD CONSTRAINT fk_inspection_request_input_employee FOREIGN KEY (inputinspection_employee_id) REFERENCES public.employee(id) ON DELETE SET NULL;


--
-- Name: inspection_request fk_inspection_request_medtech; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request
    ADD CONSTRAINT fk_inspection_request_medtech FOREIGN KEY (medical_technology_id) REFERENCES public.medical_technology(id);


--
-- Name: inspection_request fk_inspection_request_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_request
    ADD CONSTRAINT fk_inspection_request_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: leave_request fk_lr_physician; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_request
    ADD CONSTRAINT fk_lr_physician FOREIGN KEY (physician_id) REFERENCES public.employee(id);


--
-- Name: medical_record fk_medical_record_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record
    ADD CONSTRAINT fk_medical_record_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: medical_technology fk_medtech_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_technology
    ADD CONSTRAINT fk_medtech_department FOREIGN KEY (deptment_id) REFERENCES public.department(id) ON DELETE SET NULL;


--
-- Name: medical_record_disease fk_mrd_disease; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record_disease
    ADD CONSTRAINT fk_mrd_disease FOREIGN KEY (disease_id) REFERENCES public.disease(id);


--
-- Name: medical_record_disease fk_mrd_medical_record; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medical_record_disease
    ADD CONSTRAINT fk_mrd_medical_record FOREIGN KEY (medical_record_id) REFERENCES public.medical_record(id) ON DELETE CASCADE;


--
-- Name: patient_balance_transaction fk_patient_balance_transaction_patient; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_balance_transaction
    ADD CONSTRAINT fk_patient_balance_transaction_patient FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: prescription fk_prescription_drug; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prescription
    ADD CONSTRAINT fk_prescription_drug FOREIGN KEY (drug_id) REFERENCES public.drug_info(id);


--
-- Name: prescription fk_prescription_register; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prescription
    ADD CONSTRAINT fk_prescription_register FOREIGN KEY (register_id) REFERENCES public.register(id);


--
-- Name: register fk_register_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register
    ADD CONSTRAINT fk_register_department FOREIGN KEY (deptment_id) REFERENCES public.department(id);


--
-- Name: register fk_register_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register
    ADD CONSTRAINT fk_register_employee FOREIGN KEY (employee_id) REFERENCES public.employee(id);


--
-- Name: register fk_register_regist_level; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register
    ADD CONSTRAINT fk_register_regist_level FOREIGN KEY (regist_level_id) REFERENCES public.regist_level(id);


--
-- Name: register fk_register_settle_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.register
    ADD CONSTRAINT fk_register_settle_category FOREIGN KEY (settle_category_id) REFERENCES public.settle_category(id) ON DELETE SET NULL;


--
-- Name: schedule_adjust_log fk_sal_schedule; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_log
    ADD CONSTRAINT fk_sal_schedule FOREIGN KEY (schedule_id) REFERENCES public.doctor_schedule(id);


--
-- Name: schedule_adjust_request fk_sar_schedule; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_adjust_request
    ADD CONSTRAINT fk_sar_schedule FOREIGN KEY (schedule_id) REFERENCES public.doctor_schedule(id);


--
-- Name: schedule_plan fk_sp_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_plan
    ADD CONSTRAINT fk_sp_department FOREIGN KEY (department_id) REFERENCES public.department(id);


--
-- Name: user_patient_managed fk_upm_patient; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_patient_managed
    ADD CONSTRAINT fk_upm_patient FOREIGN KEY (patient_id) REFERENCES public.patient(id) ON DELETE CASCADE;


--
-- Name: user_patient_managed fk_upm_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_patient_managed
    ADD CONSTRAINT fk_upm_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict TqxD8WKVgkRGLkUYP18mE8EDbUMKASNfl1535SrZQJhSDcAD00jgcsyY1GbFNFC

